import { n as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { f as Slot } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { t as createClient } from "../_libs/supabase__supabase-js.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/supabase-D734pmWn.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium cursor-pointer transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 disabled:cursor-not-allowed [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", {
	variants: {
		variant: {
			default: "bg-primary text-primary-foreground shadow hover:bg-primary/90",
			destructive: "bg-destructive text-destructive-foreground shadow-sm hover:bg-destructive/90",
			outline: "border border-input bg-background shadow-sm hover:bg-accent hover:text-accent-foreground",
			secondary: "bg-secondary text-secondary-foreground shadow-sm hover:bg-secondary/80",
			ghost: "hover:bg-accent hover:text-accent-foreground",
			link: "text-primary underline-offset-4 hover:underline"
		},
		size: {
			default: "h-9 px-4 py-2",
			sm: "h-8 rounded-md px-3 text-xs",
			lg: "h-10 rounded-md px-8",
			icon: "h-9 w-9"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		ref,
		...props
	});
});
Button.displayName = "Button";
var supabaseUrl = {
	"BASE_URL": "/",
	"DEV": false,
	"MODE": "production",
	"PROD": true,
	"SSR": true,
	"TSS_DEV_SERVER": "false",
	"TSS_DEV_SSR_STYLES_BASEPATH": "/",
	"TSS_DEV_SSR_STYLES_ENABLED": "true",
	"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
	"TSS_INLINE_CSS_ENABLED": "false",
	"TSS_ROUTER_BASEPATH": "",
	"TSS_SERVER_FN_BASE": "/_serverFn/",
	"VITE_SUPABASE_ANON_KEY": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InlxYnlpemFzcXpnaWpua3h6Y2VwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODM5NjQxODYsImV4cCI6MjA5OTU0MDE4Nn0.O8PvxKLvhrpApRm3-UalVgs7D31p4bh-RLFS-vaKLC8",
	"VITE_SUPABASE_URL": "https://yqbyizasqzgijnkxzcep.supabase.co"
}["VITE_SUPABASE_URL"];
var supabaseAnonKey = {
	"BASE_URL": "/",
	"DEV": false,
	"MODE": "production",
	"PROD": true,
	"SSR": true,
	"TSS_DEV_SERVER": "false",
	"TSS_DEV_SSR_STYLES_BASEPATH": "/",
	"TSS_DEV_SSR_STYLES_ENABLED": "true",
	"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
	"TSS_INLINE_CSS_ENABLED": "false",
	"TSS_ROUTER_BASEPATH": "",
	"TSS_SERVER_FN_BASE": "/_serverFn/",
	"VITE_SUPABASE_ANON_KEY": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InlxYnlpemFzcXpnaWpua3h6Y2VwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODM5NjQxODYsImV4cCI6MjA5OTU0MDE4Nn0.O8PvxKLvhrpApRm3-UalVgs7D31p4bh-RLFS-vaKLC8",
	"VITE_SUPABASE_URL": "https://yqbyizasqzgijnkxzcep.supabase.co"
}["VITE_SUPABASE_ANON_KEY"];
var supabase = supabaseUrl && supabaseAnonKey ? createClient(supabaseUrl, supabaseAnonKey) : null;
var defaultSiteContent = {
	hero_title: "Esporte adaptado. Inclusão que transforma.",
	hero_subtitle: "A AMEAS promove acolhimento, autonomia e superação por meio do esporte adaptado em São Roque e região.",
	about_text: "A AMEAS é uma associação que acredita no esporte como caminho de inclusão, desenvolvimento e pertencimento para pessoas com deficiência e suas famílias.",
	founder_name: "Karina Meneguini",
	founder_bio1: "Karina Meneguini representa a liderança que aproxima pessoas, organiza esforços e transforma propósito em ação. Sua trajetória é marcada pela dedicação ao esporte adaptado, pelo cuidado com as famílias e pela construção de oportunidades reais de superação.",
	founder_bio2: "À frente da AMEAS, inspira atletas, voluntários e parceiros a acreditarem em um ambiente mais inclusivo, acolhedor e comprometido com o desenvolvimento de cada pessoa.",
	org_president_name: "Karina Meneguini",
	org_vp_name: "Diretoria Executiva",
	org_sec1_name: "Secretário(a) Geral",
	org_sec2_name: "Secretário(a) Adjunto(a)",
	org_treas1_name: "Tesoureiro(a) Geral",
	org_treas2_name: "Tesoureiro(a) Adjunto(a)",
	org_audit1_name: "Fiscal Geral",
	org_audit2_name: "Fiscal Adjunto(a)",
	test1_quote: "A AMEAS mostra que o esporte também é pertencimento. Cada treino fortalece o corpo, a confiança e os vínculos.",
	test1_author: "Família atendida",
	test2_quote: "Ver a evolução dos atletas é acompanhar histórias de coragem sendo escritas com apoio, técnica e afeto.",
	test2_author: "Parceiro institucional",
	test3_quote: "Aqui a superação acontece em equipe. O incentivo certo transforma limites em novas conquistas.",
	test3_author: "Atleta AMEAS",
	pix_key: "34017976/0001-99",
	pix_bank: "Banco do Brasil",
	pix_agency: "0523-1",
	pix_account: "48681-7",
	volunteer_title: "Seja Voluntário(a)",
	volunteer_desc: "Venha fazer parte da AMEAS! Precisamos de voluntários para apoiar treinos, eventos, atividades administrativas e muito mais. Cada hora doada transforma vidas.",
	contact_whatsapp: "(11) 99943-3480",
	instagram_url: "https://www.instagram.com/"
};
async function getSiteContent() {
	if (!supabase) return defaultSiteContent;
	const { data, error } = await supabase.from("ameas_site_content").select("key,value");
	if (error || !data) return defaultSiteContent;
	return data.reduce((content, row) => {
		if (row.key in content) content[row.key] = row.value;
		return content;
	}, { ...defaultSiteContent });
}
async function getPartnerLinks() {
	if (!supabase) return [];
	const { data, error } = await supabase.from("ameas_partners").select("slug,name,website_url,sort_order,published").eq("published", true).order("sort_order");
	return error || !data ? [] : data;
}
//#endregion
export { getSiteContent as a, getPartnerLinks as i, cn as n, supabase as o, defaultSiteContent as r, Button as t };
