//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BO_ytMYP.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "C:/Users/Manserv/OneDrive - MANSERV/Área de Trabalho/Apps/AMEAS/src/routes/__root.tsx",
		children: ["/", "/admin"],
		preloads: ["/assets/index-BOuGRB67.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BOuGRB67.js"
		} }]
	},
	"/": {
		filePath: "C:/Users/Manserv/OneDrive - MANSERV/Área de Trabalho/Apps/AMEAS/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BJG69hP8.js"]
	}
} });
//#endregion
export { tsrStartManifest };
