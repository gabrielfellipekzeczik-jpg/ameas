import { n as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as DialogOverlay$1, i as DialogDescription$1, n as DialogClose, o as DialogPortal$1, r as DialogContent$1, s as DialogTitle$1, t as Dialog$1 } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { a as getSiteContent, i as getPartnerLinks, n as cn, r as defaultSiteContent, t as Button } from "./supabase-D734pmWn.mjs";
import { A as ArrowRight, D as CircleCheck, E as Clock, O as ChevronDown, S as HandHeart, T as Copy, a as Target, c as Sparkles, d as Repeat, f as QrCode, g as MapPin, h as Menu, i as Trophy, j as Activity, k as CalendarHeart, m as MessageCircle, n as Users, s as Star, t as X, w as Gift, x as Heart, y as LayoutDashboard } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-LkhxRCA3.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var badgeVariants = cva("inline-flex items-center rounded-md border px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2", {
	variants: { variant: {
		default: "border-transparent bg-primary text-primary-foreground shadow hover:bg-primary/80",
		secondary: "border-transparent bg-secondary text-secondary-foreground hover:bg-secondary/80",
		destructive: "border-transparent bg-destructive text-destructive-foreground shadow hover:bg-destructive/80",
		outline: "text-foreground"
	} },
	defaultVariants: { variant: "default" }
});
function Badge({ className, variant, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn(badgeVariants({ variant }), className),
		...props
	});
}
var Dialog = Dialog$1;
var DialogPortal = DialogPortal$1;
var DialogOverlay = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay$1, {
	ref,
	className: cn("fixed inset-0 z-50 bg-black/80  data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
	...props
}));
DialogOverlay.displayName = DialogOverlay$1.displayName;
var DialogContent = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent$1, {
	ref,
	className: cn("fixed left-[50%] top-[50%] z-50 grid w-full max-w-lg translate-x-[-50%] translate-y-[-50%] gap-4 border bg-background p-6 shadow-lg duration-200 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 sm:rounded-lg", className),
	...props,
	children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
		className: "absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background cursor-pointer transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-accent data-[state=open]:text-muted-foreground",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: "Close"
		})]
	})]
})] }));
DialogContent.displayName = DialogContent$1.displayName;
var DialogHeader = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col space-y-1.5 text-center sm:text-left", className),
	...props
});
DialogHeader.displayName = "DialogHeader";
var DialogFooter = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", className),
	...props
});
DialogFooter.displayName = "DialogFooter";
var DialogTitle = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle$1, {
	ref,
	className: cn("text-lg font-semibold leading-none tracking-tight", className),
	...props
}));
DialogTitle.displayName = DialogTitle$1.displayName;
var DialogDescription = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription$1, {
	ref,
	className: cn("text-sm text-muted-foreground", className),
	...props
}));
DialogDescription.displayName = DialogDescription$1.displayName;
var ameas_logo_default = "/assets/ameas-logo-ByKQ8nTu.png";
var ameas_parceiros_banner_default = "/assets/ameas-parceiros-banner-qY4jQE2l.png";
var ameas_acolhimento_cafe_default = "/assets/ameas-acolhimento-cafe-DRcMIJ0T.png";
var ameas_corrida_adaptada_default = "/assets/ameas-corrida-adaptada-BaGPVSPR.png";
var ameas_parceria_tia_lina_default = "/assets/ameas-parceria-tia-lina-EULXuTE9.png";
var ameas_encontro_comunidade_default = "/assets/ameas-encontro-comunidade-C_5XCE8o.png";
var karina_meneguini_retrato_default = "/assets/karina-meneguini-retrato-C-w7w0_-.png";
var ameas_crossfit_grupo_default = "/assets/ameas-crossfit-grupo-fmZO_tnE.png";
var ameas_acao_solidaria_default = "/assets/ameas-acao-solidaria-BKXlWz6a.png";
var ameas_treino_adaptado_default = "/assets/ameas-treino-adaptado-BZoWbuz_.png";
var sponsor_rua_hum_default = "/assets/sponsor-rua-hum-qifzSStP.png";
var sponsor_escola_aquarela_default = "/assets/sponsor-escola-aquarela-CEKRCSWG.png";
var sponsor_ibicolor_default = "/assets/sponsor-ibicolor-g_BmEzOO.png";
var sponsor_vila_don_patto_default = "/assets/sponsor-vila-don-patto-Ct_LbHWE.png";
var sponsor_unimed_sao_roque_default = "/assets/sponsor-unimed-sao-roque-DnjVlxnp.png";
var sponsor_emporio_qn_default = "/assets/sponsor-emporio-qn-BRYsJHMB.png";
var sponsor_tia_lina_default = "/assets/sponsor-tia-lina-BhlIPpDk.png";
var sponsor_fernando_araujo_default = "/assets/sponsor-fernando-araujo-BKuz5fN9.png";
var sponsor_qualiser_contabilidade_default = "/assets/sponsor-qualiser-contabilidade-DbWYk4Ed.png";
var sponsor_jornal_da_economia_default = "/assets/sponsor-jornal-da-economia-B8m7275J.png";
var whatsappNumber = "5511999433480";
var whatsappDisplay = "(11) 99943-3480";
var navLinks = [
	{
		href: "#sobre",
		label: "Sobre"
	},
	{
		href: "#familias",
		label: "Famílias"
	},
	{
		href: "#fundadora",
		label: "Fundadora"
	},
	{
		href: "#missao",
		label: "Missão"
	},
	{
		href: "#galeria",
		label: "Galeria"
	},
	{
		href: "#ajudar",
		label: "Apoiar"
	},
	{
		href: "#parceiros",
		label: "Parceiros"
	},
	{
		href: "#contato",
		label: "Contato"
	}
];
var galleryImages = [
	{
		src: ameas_parceiros_banner_default,
		alt: "Banner comemorativo com parceiros da AMEAS",
		title: "Parceiros AMEAS"
	},
	{
		src: ameas_acolhimento_cafe_default,
		alt: "Grupo da AMEAS reunido em momento de acolhimento",
		title: "Acolhimento"
	},
	{
		src: ameas_corrida_adaptada_default,
		alt: "Atleta em triciclo adaptado durante atividade",
		title: "Esporte adaptado"
	},
	{
		src: ameas_parceria_tia_lina_default,
		alt: "Participantes da AMEAS em ação de parceria",
		title: "Parcerias locais"
	},
	{
		src: ameas_encontro_comunidade_default,
		alt: "Grande grupo da AMEAS reunido com banner",
		title: "Comunidade"
	},
	{
		src: ameas_crossfit_grupo_default,
		alt: "Equipe AMEAS em encontro esportivo no CrossFit",
		title: "Treino coletivo"
	},
	{
		src: ameas_acao_solidaria_default,
		alt: "Grupo da AMEAS em ação solidária",
		title: "Ação solidária"
	},
	{
		src: ameas_treino_adaptado_default,
		alt: "Mulheres da AMEAS realizando treino adaptado",
		title: "Superação em treino"
	},
	{
		src: karina_meneguini_retrato_default,
		alt: "Retrato oficial de Karina Meneguini, fundadora",
		title: "Karina Meneguini"
	}
];
var partners = [
	{
		slug: "rua-hum",
		name: "Rua Hum",
		logo: sponsor_rua_hum_default
	},
	{
		slug: "escola-aquarela",
		name: "Escola Aquarela",
		logo: sponsor_escola_aquarela_default
	},
	{
		slug: "ibicolor",
		name: "Ibicolor",
		logo: sponsor_ibicolor_default
	},
	{
		slug: "vila-don-patto",
		name: "Vila Don Patto",
		logo: sponsor_vila_don_patto_default
	},
	{
		slug: "unimed-sao-roque",
		name: "Unimed São Roque",
		logo: sponsor_unimed_sao_roque_default
	},
	{
		slug: "emporio-qn",
		name: "Empório QN",
		logo: sponsor_emporio_qn_default
	},
	{
		slug: "tia-lina",
		name: "Tia Lina",
		logo: sponsor_tia_lina_default
	},
	{
		slug: "fernando-araujo",
		name: "Fernando Araújo Artista Plástico",
		logo: sponsor_fernando_araujo_default
	},
	{
		slug: "qualiser",
		name: "Qualiser Contabilidade",
		logo: sponsor_qualiser_contabilidade_default
	},
	{
		slug: "jornal-da-economia",
		name: "Jornal da Economia",
		logo: sponsor_jornal_da_economia_default
	}
];
var values = [
	{
		icon: Target,
		title: "Missão",
		text: "Promover inclusão, autonomia e qualidade de vida por meio do esporte adaptado, criando caminhos reais de participação social."
	},
	{
		icon: Trophy,
		title: "Visão",
		text: "Ser referência regional em esporte adaptado, acolhimento e oportunidades para pessoas com deficiência e suas famílias."
	},
	{
		icon: Heart,
		title: "Valores",
		text: "Respeito, empatia, superação, compromisso, transparência, colaboração e amor pelo desenvolvimento humano."
	}
];
var donationPresets = [
	25,
	50,
	100,
	200
];
function AmeasHome() {
	const [sc, setSc] = (0, import_react.useState)(defaultSiteContent);
	const [partnerLinks, setPartnerLinks] = (0, import_react.useState)([]);
	const [donationOpen, setDonationOpen] = (0, import_react.useState)(false);
	const [menuOpen, setMenuOpen] = (0, import_react.useState)(false);
	const [selectedImage, setSelectedImage] = (0, import_react.useState)(null);
	const [copied, setCopied] = (0, import_react.useState)(false);
	const [showAllGallery, setShowAllGallery] = (0, import_react.useState)(false);
	const [donationAmount, setDonationAmount] = (0, import_react.useState)("50");
	const [volunteerOpen, setVolunteerOpen] = (0, import_react.useState)(false);
	const [volunteerForm, setVolunteerForm] = (0, import_react.useState)({
		name: "",
		email: "",
		phone: "",
		message: ""
	});
	const [volunteerSent, setVolunteerSent] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		getSiteContent().then(setSc);
		getPartnerLinks().then(setPartnerLinks);
	}, []);
	const whatsappUrl = `https://wa.me/${whatsappNumber}?text=${encodeURIComponent("Olá, AMEAS! Quero apoiar a Associação Movimento Esporte Adaptado e Superação.")}`;
	const volunteerWhatsapp = `https://wa.me/${whatsappNumber}?text=${encodeURIComponent(`Olá, AMEAS! Quero ser voluntário(a).\nNome: ${volunteerForm.name}\nE-mail: ${volunteerForm.email}\nTelefone: ${volunteerForm.phone}\n${volunteerForm.message}`)}`;
	const visiblePartners = partners.map((p) => ({
		...p,
		website_url: partnerLinks.find((l) => l.slug === p.slug)?.website_url ?? ""
	})).filter((p) => !partnerLinks.length || partnerLinks.some((l) => l.slug === p.slug && l.published));
	const year = (0, import_react.useMemo)(() => (/* @__PURE__ */ new Date()).getFullYear(), []);
	const copyPix = async () => {
		if (typeof navigator !== "undefined" && navigator.clipboard) await navigator.clipboard.writeText(sc.pix_key);
		setCopied(true);
		setTimeout(() => setCopied(false), 1800);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "min-h-screen bg-background text-foreground",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "sticky top-0 z-40 border-b border-border/50 bg-background/85 backdrop-blur-2xl",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-7xl items-center gap-4 px-4 py-2.5 sm:px-6 lg:px-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: "#inicio",
							className: "flex shrink-0 items-center gap-2.5",
							"aria-label": "Início",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "flex h-9 w-9 items-center justify-center rounded-xl border border-[#1B4B8A]/40 bg-[#1B4B8A]/10 p-1 glow-blue",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: ameas_logo_default,
									alt: "Logo AMEAS",
									className: "h-full w-full object-contain"
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "gradient-text-blue text-sm font-black uppercase tracking-wider",
								children: "AMEAS"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
							className: "hidden flex-1 items-center justify-center gap-0.5 lg:flex",
							"aria-label": "Navegação principal",
							children: navLinks.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: l.href,
								className: "rounded-xl px-2.5 py-1.5 text-xs font-semibold text-foreground/70 transition-all hover:bg-[#1B4B8A]/10 hover:text-[#7eb5f5]",
								children: l.label
							}, l.href))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "ml-auto flex items-center gap-1.5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									asChild: true,
									size: "sm",
									variant: "ghost",
									className: "hidden text-xs text-foreground/60 hover:text-[#7eb5f5] lg:inline-flex",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
										href: whatsappUrl,
										target: "_blank",
										rel: "noreferrer",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "h-3.5 w-3.5" }), " WhatsApp"]
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									size: "sm",
									onClick: () => setDonationOpen(true),
									className: "hidden bg-[#E8392A] px-3 text-xs text-white shadow-lg shadow-[#E8392A]/30 hover:bg-[#E8392A]/90 hover:shadow-[#E8392A]/50 lg:inline-flex",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { className: "h-3.5 w-3.5" }), " Doar"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									asChild: true,
									size: "sm",
									variant: "ghost",
									className: "hidden px-2 text-foreground/40 hover:text-[#7eb5f5] lg:inline-flex",
									title: "Painel admin",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
										href: "/admin",
										"aria-label": "Painel administrativo",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LayoutDashboard, { className: "h-4 w-4" })
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "ghost",
									size: "icon",
									className: "h-8 w-8 text-foreground/60 lg:hidden",
									onClick: () => setMenuOpen((c) => !c),
									"aria-label": "Menu",
									children: menuOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "h-4 w-4" })
								})
							]
						})
					]
				}), menuOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "border-t border-border/50 bg-background/95 px-4 py-3 backdrop-blur-xl lg:hidden",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
						className: "mx-auto grid max-w-7xl gap-1",
						children: [navLinks.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: l.href,
							onClick: () => setMenuOpen(false),
							className: "rounded-xl px-3 py-2.5 text-sm font-semibold text-foreground/70 hover:bg-[#1B4B8A]/10 hover:text-[#7eb5f5]",
							children: l.label
						}, l.href)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								onClick: () => setDonationOpen(true),
								className: "flex-1 bg-[#E8392A] text-xs text-white",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { className: "h-3.5 w-3.5" }), " Doar Agora"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								variant: "ghost",
								size: "sm",
								className: "text-foreground/50",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: "/admin",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LayoutDashboard, { className: "h-4 w-4" })
								})
							})]
						})]
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				id: "inicio",
				className: "relative overflow-hidden bg-hero-pattern",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "pointer-events-none absolute -top-40 left-1/4 h-96 w-96 rounded-full bg-[#1B4B8A]/20 blur-3xl",
						"aria-hidden": "true"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "pointer-events-none absolute -bottom-20 right-1/4 h-80 w-80 rounded-full bg-[#E8392A]/10 blur-3xl",
						"aria-hidden": "true"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto grid max-w-7xl items-center gap-10 px-4 py-16 sm:px-6 lg:grid-cols-2 lg:px-8 lg:py-24",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "max-w-2xl",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									className: "border border-[#1B4B8A]/30 bg-[#1B4B8A]/10 px-3 py-1 text-[#7eb5f5] hover:bg-[#1B4B8A]/20",
									children: "Associação Movimento Esporte Adaptado e Superação"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
									className: "mt-6 text-5xl font-black leading-tight sm:text-6xl lg:text-7xl",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "gradient-text",
										children: "AMEAS"
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-4 text-2xl font-bold text-foreground/90 sm:text-3xl",
									children: sc.hero_title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-5 text-lg leading-8 text-foreground/60",
									children: sc.hero_subtitle
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-8 flex flex-col gap-3 sm:flex-row",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										asChild: true,
										size: "lg",
										className: "rounded-2xl bg-[#E8392A] text-white shadow-lg shadow-[#E8392A]/30 hover:bg-[#E8392A]/90 hover:shadow-[#E8392A]/50",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
											href: "#ajudar",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { "aria-hidden": "true" }), " Fazer Doação"]
										})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										asChild: true,
										size: "lg",
										variant: "outline",
										className: "rounded-2xl border-[#1B4B8A]/40 text-[#7eb5f5] hover:bg-[#1B4B8A]/10",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
											href: whatsappUrl,
											target: "_blank",
											rel: "noreferrer",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { "aria-hidden": "true" }), " WhatsApp"]
										})
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-8 flex flex-wrap gap-4 text-sm font-semibold text-foreground/60",
									children: [
										"Inclusão",
										"Acolhimento",
										"Superação"
									].map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "flex items-center gap-2",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-4 w-4 text-[#E8392A]" }),
											" ",
											t
										]
									}, t))
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-4 md:grid-cols-[1.2fr_0.8fr]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("figure", {
								className: "glass neon-border relative flex min-h-[340px] items-center justify-center overflow-hidden rounded-3xl p-3 shadow-2xl",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: ameas_treino_adaptado_default,
									alt: "Atletas da AMEAS em treino adaptado",
									className: "max-h-[520px] w-full object-contain",
									loading: "eager"
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid gap-4",
								children: [ameas_corrida_adaptada_default, ameas_crossfit_grupo_default].map((src, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("figure", {
									className: "glass flex min-h-[160px] items-center justify-center overflow-hidden rounded-2xl p-3",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src,
										alt: "",
										className: "max-h-60 w-full object-contain"
									})
								}, i))
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mx-auto flex max-w-7xl justify-center px-4 pb-10 sm:px-6 lg:px-8",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: "#sobre",
							className: "inline-flex items-center gap-2 text-sm font-semibold text-foreground/40 hover:text-[#7eb5f5] transition-colors",
							children: ["Conheça a associação ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "h-4 w-4" })]
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				id: "sobre",
				className: "py-20 sm:py-24",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto grid max-w-7xl gap-12 px-4 sm:px-6 lg:grid-cols-2 lg:px-8",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "section-kicker",
							children: "Sobre a Associação"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
							className: "mt-4 text-3xl font-black sm:text-4xl",
							children: ["Movimento, esporte e acolhimento para ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "gradient-text",
								children: "transformar vidas."
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-6 space-y-4 text-base leading-8 text-foreground/60",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "A AMEAS nasceu do compromisso com a inclusão e com a superação diária de pessoas que encontram no esporte adaptado um espaço de desenvolvimento, amizade e conquista." }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: sc.about_text }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Mais do que treinos, a AMEAS constrói uma rede de apoio em que cada pessoa é vista, respeitada e incentivada a alcançar novas possibilidades." })
							]
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-4 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("figure", {
							className: "glass neon-border flex min-h-[280px] items-center justify-center overflow-hidden rounded-3xl p-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: ameas_encontro_comunidade_default,
								alt: "Comunidade AMEAS reunida",
								className: "max-h-[360px] w-full object-contain",
								loading: "lazy"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "glass-blue rounded-3xl p-5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "h-7 w-7 text-[#f59e0b] mb-3" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-black text-foreground",
										children: "Impacto humano"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-sm leading-6 text-foreground/60",
										children: "Inclusão que começa no treino e alcança a autoestima, a família e a comunidade."
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "glass rounded-3xl border border-[#E8392A]/20 p-5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarHeart, { className: "h-7 w-7 text-[#E8392A] mb-3" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-black text-foreground",
										children: "Presença contínua"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-sm leading-6 text-foreground/60",
										children: "Projetos, encontros e ações que mantêm o esporte adaptado vivo e acessível."
									})
								]
							})]
						})]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				id: "familias",
				className: "py-20 sm:py-24",
				style: { background: "radial-gradient(ellipse 80% 60% at 50% 0%, rgba(27,75,138,.12), transparent), var(--color-secondary)" },
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-7xl px-4 sm:px-6 lg:px-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "max-w-3xl",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "section-kicker",
									children: "Famílias atípicas"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
									className: "mt-4 text-3xl font-black sm:text-4xl",
									children: ["Cuidar de quem cuida também faz parte da ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "gradient-text",
										children: "nossa missão."
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-5 text-lg leading-8 text-foreground/60",
									children: "Além do esporte adaptado, a AMEAS oferece uma rede de acolhimento e assistência social para as famílias atípicas da associação."
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-12 grid gap-5 md:grid-cols-3",
							children: [
								{
									icon: Heart,
									label: "Suporte psicológico",
									border: "border-[#E8392A]/20 bg-[#E8392A]/5",
									iconCls: "text-[#E8392A]",
									text: "Espaço de escuta e acolhimento emocional para mães, pais e responsáveis enfrentarem os desafios da rotina com mais apoio e segurança."
								},
								{
									icon: Users,
									label: "Assistência social",
									border: "border-[#1B4B8A]/20 bg-[#1B4B8A]/5",
									iconCls: "text-[#7eb5f5]",
									text: "Orientação e encaminhamentos para fortalecer o acesso das famílias a direitos, serviços e oportunidades na comunidade."
								},
								{
									icon: Activity,
									label: "Pilates para as mães",
									border: "border-[#f59e0b]/20 bg-[#f59e0b]/5",
									iconCls: "text-[#f59e0b]",
									text: "Aulas de Pilates conduzidas por voluntários, criando um momento de cuidado com o corpo, descanso e fortalecimento."
								}
							].map(({ icon: Icon, label, border, iconCls, text }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: `glass neon-border rounded-3xl border p-7 ${border}`,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: `flex h-12 w-12 items-center justify-center rounded-2xl bg-white/5 ${iconCls}`,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-4 text-xl font-black text-foreground",
										children: label
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-3 text-sm leading-7 text-foreground/60",
										children: text
									})
								]
							}, label))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-8 rounded-3xl border border-[#1B4B8A]/20 bg-[#1B4B8A]/10 p-8 backdrop-blur",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-lg font-bold text-foreground",
								children: "Na AMEAS, atletas e famílias caminham juntos: o esporte abre caminhos e a assistência social sustenta a rede de apoio."
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-sm leading-7 text-foreground/50",
								children: "Todas essas ações são realizadas com a dedicação de voluntários e parceiros que doam tempo, conhecimento e cuidado para transformar vidas."
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				id: "fundadora",
				className: "py-20 sm:py-24 bg-secondary",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto grid max-w-7xl items-center gap-12 px-4 sm:px-6 lg:grid-cols-[0.8fr_1.2fr] lg:px-8",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
						className: "relative mx-auto w-full max-w-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "absolute inset-0 rounded-3xl bg-gradient-to-br from-[#1B4B8A]/30 to-[#E8392A]/20 blur-2xl",
							"aria-hidden": "true"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "glass-blue relative overflow-hidden rounded-3xl border border-[#1B4B8A]/40 p-4 shadow-2xl glow-blue",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: karina_meneguini_retrato_default,
								alt: `${sc.founder_name}, fundadora da AMEAS`,
								className: "max-h-[520px] w-full rounded-2xl object-contain",
								loading: "lazy"
							})
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "section-kicker",
							children: "Fundadora"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-4 text-3xl font-black sm:text-4xl",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "gradient-text",
								children: sc.founder_name
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 text-lg leading-8 text-foreground/70",
							children: sc.founder_bio1
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-lg leading-8 text-foreground/70",
							children: sc.founder_bio2
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-8 grid gap-3 sm:grid-cols-3",
							children: [
								"Dedicação",
								"Liderança transformadora",
								"Inclusão com afeto"
							].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "glass-blue rounded-2xl border border-[#1B4B8A]/20 p-4 text-center text-sm font-bold text-[#7eb5f5]",
								children: item
							}, item))
						})
					] })]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				id: "missao",
				className: "py-20 sm:py-24",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-7xl px-4 sm:px-6 lg:px-8",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "max-w-3xl",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "section-kicker",
							children: "Missão, Visão e Valores"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
							className: "mt-4 text-3xl font-black sm:text-4xl",
							children: ["Princípios que orientam cada treino, encontro e ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "gradient-text",
								children: "conquista."
							})]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-12 grid gap-5 md:grid-cols-3",
						children: values.map((item, i) => {
							const Icon = item.icon;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: `glass neon-border rounded-3xl border p-7 ${[
									"border-[#1B4B8A]/30 bg-[#1B4B8A]/5 text-[#7eb5f5]",
									"border-[#38bdf8]/30 bg-[#38bdf8]/5 text-[#38bdf8]",
									"border-[#E8392A]/30 bg-[#E8392A]/5 text-[#E8392A]"
								][i]}`,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: `flex h-12 w-12 items-center justify-center rounded-2xl bg-white/5`,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-4 text-xl font-black text-foreground",
										children: item.title
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-3 text-sm leading-7 text-foreground/60",
										children: item.text
									})
								]
							}, item.title);
						})
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "py-20 sm:py-24",
				style: { background: "radial-gradient(ellipse 70% 50% at 50% 0%, rgba(27,75,138,.15), transparent), var(--color-secondary)" },
				"aria-labelledby": "org-title",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-3xl px-4 sm:px-6 lg:px-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-12 text-center",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "section-kicker",
								children: "Organograma"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
								id: "org-title",
								className: "mt-4 text-3xl font-black sm:text-4xl",
								children: ["Uma rede organizada para ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "gradient-text",
									children: "cuidar e apoiar."
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col items-center",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative w-60 overflow-hidden rounded-3xl border border-[#1B4B8A]/50 bg-gradient-to-br from-[#1B4B8A]/80 to-[#0d1b2e]/90 px-5 py-5 text-center shadow-xl glow-blue backdrop-blur",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mx-auto mb-3 h-16 w-16 overflow-hidden rounded-full border-2 border-[#7eb5f5]/50 shadow-lg glow-blue",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
											src: karina_meneguini_retrato_default,
											alt: sc.org_president_name,
											className: "h-full w-full object-cover object-top"
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[10px] font-black uppercase tracking-widest text-[#7eb5f5]/80",
										children: "Presidente"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-0.5 text-sm font-black text-white",
										children: sc.org_president_name
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "org-line-v h-8",
								"aria-hidden": "true"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col items-center",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "w-60 rounded-3xl border border-border/50 bg-card/80 px-5 py-4 text-center shadow-md backdrop-blur",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px] font-black uppercase tracking-widest text-[#E8392A]",
									children: "Vice-Presidente"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-0.5 text-sm font-black text-foreground",
									children: sc.org_vp_name
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "org-line-v h-8",
								"aria-hidden": "true"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex justify-center",
							"aria-hidden": "true",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "org-line-h w-2/3" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-0 grid grid-cols-1 gap-5 sm:grid-cols-3",
							children: [
								{
									dept: "Secretaria",
									color: "text-[#7eb5f5]",
									border: "border-[#1B4B8A]/25",
									c1: "Primeiro Secretário",
									n1: sc.org_sec1_name,
									c2: "Segundo Secretário",
									n2: sc.org_sec2_name
								},
								{
									dept: "Tesouraria",
									color: "text-[#38bdf8]",
									border: "border-[#38bdf8]/25",
									c1: "Primeiro Tesoureiro",
									n1: sc.org_treas1_name,
									c2: "Segundo Tesoureiro",
									n2: sc.org_treas2_name
								},
								{
									dept: "Fiscalização",
									color: "text-[#E8392A]",
									border: "border-[#E8392A]/25",
									c1: "Primeiro Fiscal",
									n1: sc.org_audit1_name,
									c2: "Segundo Fiscal",
									n2: sc.org_audit2_name
								}
							].map(({ dept, color, border, c1, n1, c2, n2 }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-col items-center gap-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "org-line-v h-8",
										"aria-hidden": "true"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: `text-[10px] font-black uppercase tracking-widest ${color}`,
										children: dept
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrgCard, {
										cargo: c1,
										nome: n1,
										border
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrgCard, {
										cargo: c2,
										nome: n2,
										border
									})
								]
							}, dept))
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				id: "ajudar",
				className: "bg-donation-pattern py-20 sm:py-24",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-7xl px-4 sm:px-6 lg:px-8",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto max-w-3xl text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "section-kicker",
								children: "Como Ajudar"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-4 text-3xl font-black sm:text-4xl",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "gradient-text",
									children: "Apoie a AMEAS"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-5 text-lg leading-8 text-foreground/60",
								children: "Escolha a forma de contribuir que combina com você. Cada apoio mantém o esporte adaptado em movimento."
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-14 grid items-start gap-6 lg:grid-cols-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "glass neon-border rounded-3xl border border-[#1B4B8A]/20 p-7",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "flex h-12 w-12 items-center justify-center rounded-2xl bg-[#1B4B8A]/15 text-[#7eb5f5]",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Repeat, {})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-4 text-2xl font-black text-foreground",
										children: "Apoiador Mensal"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-1 text-3xl font-black text-[#7eb5f5]",
										children: ["R$ 30", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-base font-bold text-foreground/40",
											children: "/mês"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
										className: "mt-5 space-y-3 text-sm text-foreground/60",
										children: [
											"Apoio contínuo aos treinos",
											"Materiais e equipamentos adaptados",
											"Relatos das conquistas dos atletas"
										].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
											className: "flex gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "mt-0.5 h-4 w-4 shrink-0 text-[#7eb5f5]" }), item]
										}, item))
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										onClick: () => setDonationOpen(true),
										className: "mt-6 w-full rounded-2xl bg-[#1B4B8A]/20 text-[#7eb5f5] border border-[#1B4B8A]/30 hover:bg-[#1B4B8A]/40",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QrCode, {}), " Doar via PIX"]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative overflow-hidden rounded-3xl border border-[#1B4B8A]/50 bg-gradient-to-br from-[#1B4B8A]/60 to-[#0d1b2e]/80 p-7 shadow-2xl glow-blue backdrop-blur lg:-mt-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "absolute right-4 top-4 flex items-center gap-1 rounded-full border border-[#f59e0b]/30 bg-[#f59e0b]/20 px-3 py-1 text-xs font-black text-[#f59e0b]",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: "h-3 w-3" }), " Mais popular"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "flex h-12 w-12 items-center justify-center rounded-2xl bg-white/10 text-white",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gift, {})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-4 text-2xl font-black text-white",
										children: "Doação Única"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-1 text-3xl font-black text-white",
										children: [
											"R$ ",
											donationAmount || "0",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-base font-bold text-white/50",
												children: " por doação"
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mt-5 flex flex-wrap gap-2",
										children: donationPresets.map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											onClick: () => setDonationAmount(String(v)),
											className: `rounded-full border px-4 py-1.5 text-sm font-bold transition-all ${donationAmount === String(v) ? "border-[#f59e0b] bg-[#f59e0b] text-black" : "border-white/20 text-white/70 hover:border-white/40"}`,
											children: ["R$ ", v]
										}, v))
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-4",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											htmlFor: "valor-livre",
											className: "text-xs font-bold uppercase text-white/50",
											children: "Valor livre"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											id: "valor-livre",
											inputMode: "numeric",
											value: donationAmount,
											onChange: (e) => setDonationAmount(e.target.value.replace(/\D/g, "")),
											placeholder: "Digite o valor",
											className: "mt-2 w-full rounded-2xl border border-white/20 bg-white/10 px-4 py-2 text-base font-bold text-white placeholder:text-white/30 focus:outline-none focus:ring-2 focus:ring-[#7eb5f5]"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										onClick: () => setDonationOpen(true),
										className: "mt-5 w-full rounded-2xl bg-[#E8392A] text-white shadow-lg shadow-[#E8392A]/30 hover:bg-[#E8392A]/90",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, {}),
											" Doar R$ ",
											donationAmount || "0",
											" via PIX"
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-3 text-center text-xs text-white/40",
										children: [
											sc.pix_bank,
											" · Ag. ",
											sc.pix_agency,
											" · CC ",
											sc.pix_account
										]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "glass neon-border rounded-3xl border border-[#E8392A]/20 p-7",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "flex h-12 w-12 items-center justify-center rounded-2xl bg-[#E8392A]/15 text-[#E8392A]",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HandHeart, {})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-4 text-2xl font-black text-foreground",
										children: sc.volunteer_title
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-3 text-sm leading-7 text-foreground/60",
										children: sc.volunteer_desc
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										onClick: () => setVolunteerOpen(true),
										className: "mt-6 w-full rounded-2xl bg-[#E8392A]/15 text-[#E8392A] border border-[#E8392A]/30 hover:bg-[#E8392A]/30",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, {}), " Quero ser voluntário(a)"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										asChild: true,
										variant: "outline",
										className: "mt-3 w-full rounded-2xl border-[#1B4B8A]/30 text-[#7eb5f5] hover:bg-[#1B4B8A]/10",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
											href: whatsappUrl,
											target: "_blank",
											rel: "noreferrer",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, {}), " Falar no WhatsApp"]
										})
									})
								]
							})
						]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				id: "parceiros",
				className: "py-20 sm:py-24",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-7xl px-4 sm:px-6 lg:px-8",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "max-w-3xl",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "section-kicker",
							children: "Apoiadores e Patrocinadores"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
							className: "mt-4 text-3xl font-black sm:text-4xl",
							children: ["Parceiros que fortalecem cada ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "gradient-text",
								children: "história de superação."
							})]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-5",
						children: visiblePartners.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: p.website_url || void 0,
							target: p.website_url ? "_blank" : void 0,
							rel: p.website_url ? "noreferrer" : void 0,
							onClick: (e) => !p.website_url && e.preventDefault(),
							className: "glass neon-border group flex flex-col items-center gap-3 rounded-3xl border border-border/40 p-5 text-center transition-all hover:border-[#1B4B8A]/40",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "flex h-20 w-full items-center justify-center rounded-2xl bg-white p-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: p.logo,
									alt: `Logo de ${p.name}`,
									className: "h-full w-full object-contain",
									loading: "lazy"
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs font-black uppercase leading-snug text-foreground/70 group-hover:text-[#7eb5f5] transition-colors",
								children: p.name
							})]
						}, p.name))
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				id: "galeria",
				className: "py-20 sm:py-24",
				style: { background: "var(--color-secondary)" },
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-7xl px-4 sm:px-6 lg:px-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "max-w-3xl",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "section-kicker",
								children: "Galeria"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
								className: "mt-4 text-3xl font-black sm:text-4xl",
								children: ["Histórias da AMEAS ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "gradient-text",
									children: "em movimento."
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-4",
							children: (showAllGallery ? galleryImages : galleryImages.slice(0, 8)).map((img) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: () => setSelectedImage(img),
								className: "glass neon-border group overflow-hidden rounded-3xl border border-border/30 text-left transition-all hover:border-[#1B4B8A]/40",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "flex aspect-[4/3] w-full items-center justify-center overflow-hidden bg-background/30 p-2",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: img.src,
										alt: img.alt,
										className: "max-h-full w-full object-contain transition-transform group-hover:scale-105",
										loading: "lazy"
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "flex items-center justify-between gap-3 px-4 py-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-sm font-black text-foreground/80",
										children: img.title
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-4 w-4 text-[#7eb5f5] transition-transform group-hover:translate-x-1" })]
								})]
							}, img.src))
						}),
						galleryImages.length > 8 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-8 flex justify-center",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "outline",
								size: "lg",
								onClick: () => setShowAllGallery((v) => !v),
								className: "rounded-2xl border-[#1B4B8A]/40 px-8 text-[#7eb5f5] hover:bg-[#1B4B8A]/10",
								children: [showAllGallery ? "Ver menos" : "Ver mais fotos", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: `h-4 w-4 transition-transform ${showAllGallery ? "rotate-180" : ""}` })]
							})
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "py-20 sm:py-24",
				"aria-labelledby": "dep-title",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-7xl px-4 sm:px-6 lg:px-8",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "max-w-3xl",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "section-kicker",
							children: "Depoimentos"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
							id: "dep-title",
							className: "mt-4 text-3xl font-black sm:text-4xl",
							children: ["Vozes de quem vive a ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "gradient-text",
								children: "inclusão de perto."
							})]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-12 grid gap-5 lg:grid-cols-3",
						children: [
							{
								quote: sc.test1_quote,
								author: sc.test1_author,
								border: "border-[#1B4B8A]/20"
							},
							{
								quote: sc.test2_quote,
								author: sc.test2_author,
								border: "border-[#38bdf8]/20"
							},
							{
								quote: sc.test3_quote,
								author: sc.test3_author,
								border: "border-[#E8392A]/20"
							}
						].map((t, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: `glass neon-border rounded-3xl border p-7 ${t.border}`,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex gap-1 text-[#f59e0b] mb-4",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "h-5 w-5" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "h-5 w-5" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "h-5 w-5" })
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("blockquote", {
									className: "text-base font-semibold leading-8 text-foreground/80",
									children: [
										"\"",
										t.quote,
										"\""
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-4 text-sm font-black text-[#7eb5f5]",
									children: t.author
								})
							]
						}, i))
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
				id: "contato",
				className: "border-t border-border/30 py-14",
				style: { background: "var(--color-card)" },
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto grid max-w-7xl gap-10 px-4 sm:px-6 lg:grid-cols-[1.2fr_0.9fr_0.9fr] lg:px-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "flex h-14 w-14 items-center justify-center rounded-2xl border border-[#1B4B8A]/30 bg-[#1B4B8A]/10 p-2 glow-blue",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: ameas_logo_default,
									alt: "Logo AMEAS",
									className: "h-full w-full object-contain",
									loading: "lazy"
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "gradient-text-blue text-xl font-black",
								children: "AMEAS"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-foreground/40",
								children: "Associação Movimento Esporte Adaptado e Superação"
							})] })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-5 max-w-sm text-sm leading-7 text-foreground/50",
							children: "Inclusão, esporte adaptado, acolhimento e superação construídos com atletas, famílias, voluntários e parceiros."
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-3 text-sm text-foreground/60",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-black text-foreground",
									children: "Contato"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
									className: "flex items-center gap-2 hover:text-[#7eb5f5] transition-colors",
									href: whatsappUrl,
									target: "_blank",
									rel: "noreferrer",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "h-4 w-4" }),
										" ",
										sc.contact_whatsapp || whatsappDisplay
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "h-4 w-4" }), " São Roque e região"]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-3 text-sm text-foreground/60",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-black text-foreground",
									children: "Doações"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["PIX CNPJ ", sc.pix_key] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
									sc.pix_bank,
									" · Ag. ",
									sc.pix_agency,
									" · CC ",
									sc.pix_account
								] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									onClick: () => setDonationOpen(true),
									className: "rounded-2xl bg-[#E8392A] text-white shadow-md shadow-[#E8392A]/25 hover:bg-[#E8392A]/90",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, {}), " Doar Agora"]
								})
							]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto mt-10 max-w-7xl border-t border-border/20 px-4 pt-6 text-xs text-foreground/30 sm:px-6 lg:px-8",
					children: [
						"© ",
						year,
						" AMEAS. Todos os direitos reservados."
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				onClick: () => setDonationOpen(true),
				className: "fixed bottom-5 right-5 z-40 h-14 rounded-full bg-[#E8392A] px-5 text-white shadow-xl shadow-[#E8392A]/30 donation-pulse hover:bg-[#E8392A]/90 hover:shadow-[#E8392A]/50",
				"aria-label": "Fazer doação",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, {}), " Fazer Doação"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DonationDialog, {
				open: donationOpen,
				onOpenChange: setDonationOpen,
				copied,
				onCopyPix: copyPix,
				sc,
				whatsappUrl
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: volunteerOpen,
				onOpenChange: setVolunteerOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "max-h-[90vh] overflow-auto rounded-3xl border border-[#1B4B8A]/20 bg-card/95 backdrop-blur",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, {
						className: "flex items-center gap-2 text-xl",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HandHeart, { className: "text-[#E8392A]" }),
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "gradient-text",
								children: "Seja Voluntário(a)"
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
						className: "text-foreground/50",
						children: "Preencha o formulário e entraremos em contato."
					})] }), volunteerSent ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "py-8 text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "mx-auto h-16 w-16 text-green-400 mb-4" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-lg font-black text-foreground",
								children: "Mensagem enviada!"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-foreground/60",
								children: "Em breve a AMEAS entrará em contato com você."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								onClick: () => {
									setVolunteerOpen(false);
									setVolunteerSent(false);
								},
								className: "mt-6 rounded-2xl bg-[#E8392A] text-white",
								children: "Fechar"
							})
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-4 sm:grid-cols-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "text-xs font-bold uppercase tracking-wide text-foreground/50",
										children: "Nome completo *"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										value: volunteerForm.name,
										onChange: (e) => setVolunteerForm({
											...volunteerForm,
											name: e.target.value
										}),
										placeholder: "Seu nome",
										className: "w-full rounded-2xl border border-border/40 bg-white/5 px-4 py-2.5 text-sm text-foreground placeholder:text-foreground/30 focus:outline-none focus:ring-2 focus:ring-[#1B4B8A]/50"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "text-xs font-bold uppercase tracking-wide text-foreground/50",
										children: "E-mail *"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "email",
										value: volunteerForm.email,
										onChange: (e) => setVolunteerForm({
											...volunteerForm,
											email: e.target.value
										}),
										placeholder: "seu@email.com",
										className: "w-full rounded-2xl border border-border/40 bg-white/5 px-4 py-2.5 text-sm text-foreground placeholder:text-foreground/30 focus:outline-none focus:ring-2 focus:ring-[#1B4B8A]/50"
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "text-xs font-bold uppercase tracking-wide text-foreground/50",
									children: "Telefone / WhatsApp"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: volunteerForm.phone,
									onChange: (e) => setVolunteerForm({
										...volunteerForm,
										phone: e.target.value
									}),
									placeholder: "(11) 99999-9999",
									className: "w-full rounded-2xl border border-border/40 bg-white/5 px-4 py-2.5 text-sm text-foreground placeholder:text-foreground/30 focus:outline-none focus:ring-2 focus:ring-[#1B4B8A]/50"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "text-xs font-bold uppercase tracking-wide text-foreground/50",
									children: "Como quer ajudar?"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
									rows: 3,
									value: volunteerForm.message,
									onChange: (e) => setVolunteerForm({
										...volunteerForm,
										message: e.target.value
									}),
									placeholder: "Conte um pouco sobre você e sua disponibilidade…",
									className: "w-full resize-none rounded-2xl border border-border/40 bg-white/5 px-4 py-2.5 text-sm text-foreground placeholder:text-foreground/30 focus:outline-none focus:ring-2 focus:ring-[#1B4B8A]/50"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex gap-3",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									asChild: true,
									className: "flex-1 rounded-2xl bg-[#E8392A] text-white shadow-lg shadow-[#E8392A]/30 hover:bg-[#E8392A]/90",
									onClick: () => volunteerForm.name && volunteerForm.email && setVolunteerSent(true),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
										href: volunteerWhatsapp,
										target: "_blank",
										rel: "noreferrer",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, {}), " Enviar pelo WhatsApp"]
									})
								})
							})
						]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: Boolean(selectedImage),
				onOpenChange: (open) => !open && setSelectedImage(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "max-h-[90vh] max-w-5xl overflow-auto rounded-3xl border border-[#1B4B8A]/20 bg-card/95 p-4 backdrop-blur",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
						className: "gradient-text",
						children: selectedImage?.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
						className: "text-foreground/50",
						children: selectedImage?.alt
					})] }), selectedImage && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex min-h-[55vh] items-center justify-center rounded-2xl bg-background/30 p-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: selectedImage.src,
							alt: selectedImage.alt,
							className: "max-h-[72vh] w-full object-contain"
						})
					})]
				})
			})
		]
	});
}
function OrgCard({ cargo, nome, border = "border-border/40" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `glass w-full rounded-2xl border p-4 text-center backdrop-blur ${border}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[10px] font-black uppercase tracking-wide text-foreground/50",
			children: cargo
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm font-black text-foreground",
			children: nome
		})]
	});
}
function DemoQr() {
	const qrCells = [
		0,
		1,
		2,
		3,
		4,
		5,
		6,
		8,
		10,
		12,
		14,
		16,
		18,
		20,
		22,
		24,
		25,
		26,
		27,
		28,
		29,
		30,
		33,
		35,
		37,
		39,
		40,
		42,
		44,
		46,
		48,
		50,
		51,
		52,
		53,
		54,
		55,
		56,
		60,
		61,
		63,
		65,
		67,
		69,
		72,
		75,
		76,
		78,
		80,
		82,
		84,
		86,
		87,
		88,
		91,
		93,
		95,
		96,
		98,
		100,
		104,
		105,
		106,
		108,
		111,
		113,
		115,
		118,
		120,
		121,
		122,
		124,
		126,
		128,
		130,
		132,
		133,
		135,
		137,
		139,
		140,
		141,
		144,
		147,
		149,
		151,
		153,
		155,
		157,
		160,
		162,
		164,
		166,
		168,
		170,
		172,
		174,
		176,
		177,
		178,
		180,
		184,
		186,
		188,
		190,
		192,
		194,
		196,
		198,
		200,
		201,
		202,
		203,
		204,
		205,
		206,
		208,
		211,
		213,
		215,
		217,
		219,
		221,
		223,
		225,
		226,
		228,
		230,
		232,
		234,
		236,
		238,
		240,
		242,
		244,
		245,
		246,
		247,
		248,
		249,
		250,
		252,
		254,
		256,
		258,
		260,
		262,
		264,
		266,
		268,
		270,
		272,
		273,
		274,
		275,
		276,
		277,
		278,
		280,
		282,
		284,
		287,
		289,
		291,
		293,
		295,
		297,
		299,
		301,
		303,
		304,
		305,
		306,
		307,
		308,
		309,
		310,
		314,
		316,
		318,
		320,
		322,
		324,
		326,
		329,
		331,
		333,
		335,
		337,
		339,
		341,
		342,
		344,
		346,
		348,
		350,
		352,
		354,
		356,
		358,
		360
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto w-full max-w-52 rounded-2xl border border-[#1B4B8A]/20 bg-background/80 p-3 backdrop-blur",
		"aria-label": "QR Code demonstrativo para PIX",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid aspect-square grid-cols-[repeat(19,minmax(0,1fr))] gap-0.5",
			children: Array.from({ length: 361 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: qrCells.includes(i) ? "rounded-[1px] bg-[#1B4B8A]" : "rounded-[1px] bg-background/40" }, i))
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-center text-[0.65rem] font-bold uppercase text-foreground/40",
			children: "QR Code demonstrativo"
		})]
	});
}
function DonationDialog({ open, onOpenChange, copied, onCopyPix, sc, whatsappUrl }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-h-[90vh] overflow-auto rounded-3xl border border-[#1B4B8A]/20 bg-card/95 backdrop-blur",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, {
				className: "flex items-center gap-2 text-xl",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { className: "text-[#E8392A]" }),
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "gradient-text",
						children: "Apoie a AMEAS"
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
				className: "text-foreground/50",
				children: "Sua doação fortalece esporte adaptado, inclusão e acolhimento."
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-5 sm:grid-cols-[0.9fr_1.1fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DemoQr, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-2xl border border-[#1B4B8A]/20 bg-[#1B4B8A]/5 p-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-bold uppercase text-foreground/50",
								children: "PIX CNPJ"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 break-words text-lg font-black text-[#7eb5f5]",
								children: sc.pix_key
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "rounded-2xl border border-border/20 bg-background/30 p-3 text-xs text-foreground/50",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
								sc.pix_bank,
								" · Ag. ",
								sc.pix_agency,
								" · CC ",
								sc.pix_account
							] })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							onClick: onCopyPix,
							className: "w-full rounded-2xl bg-[#1B4B8A] text-white hover:bg-[#1B4B8A]/90",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, {}),
								" ",
								copied ? "Chave copiada ✓" : "Copiar PIX"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							variant: "outline",
							className: "w-full rounded-2xl border-[#E8392A]/40 text-[#E8392A] hover:bg-[#E8392A]/10",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: whatsappUrl,
								target: "_blank",
								rel: "noreferrer",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, {}), " Chamar no WhatsApp"]
							})
						})
					]
				})]
			})]
		})
	});
}
//#endregion
export { AmeasHome as component };
