globalThis.__nitro_main__ = import.meta.url;
import { i as HTTPError, n as defineLazyEventHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { t as HookableCore } from "./_libs/hookable.mjs";
import { r as FastResponse } from "./_libs/h3-v2+rou3+srvx.mjs";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/favicon.png": {
		"type": "image/png",
		"etag": "\"ccb-Ew/dJ+NrT6tLxYxF4OVmdAb61sY\"",
		"mtime": "2026-09-23T12:06:04.697Z",
		"size": 3275,
		"path": "../public/favicon.png"
	},
	"/robots.txt": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"a0-CKGXSIe7TSsqDTmGm/nY1t/o5d0\"",
		"mtime": "2026-09-23T12:06:04.710Z",
		"size": 160,
		"path": "../public/robots.txt"
	},
	"/assets/ameas-corrida-adaptada-BaGPVSPR.png": {
		"type": "image/png",
		"etag": "\"4c422-V7YGHw8SuZBSrx8DeEdOdtQS+1E\"",
		"mtime": "2026-09-25T19:16:33.990Z",
		"size": 312354,
		"path": "../public/assets/ameas-corrida-adaptada-BaGPVSPR.png"
	},
	"/assets/ameas-logo-ByKQ8nTu.png": {
		"type": "image/png",
		"etag": "\"1592c-lVOPvYZiYV+UxIuo1pUwnT2UIxU\"",
		"mtime": "2026-09-25T19:16:34.001Z",
		"size": 88364,
		"path": "../public/assets/ameas-logo-ByKQ8nTu.png"
	},
	"/assets/pix-qrcode-Ctx5h4SP.png": {
		"type": "image/png",
		"etag": "\"3712-bYOa6kpKNbxnUv4XhrUWL8HicTc\"",
		"mtime": "2026-09-25T19:16:34.009Z",
		"size": 14098,
		"path": "../public/assets/pix-qrcode-Ctx5h4SP.png"
	},
	"/assets/karina-meneguini-retrato-C-w7w0_-.png": {
		"type": "image/png",
		"etag": "\"f511-DnhDMvM3lV99Emnc9OGPkDc2C6g\"",
		"mtime": "2026-09-25T19:16:34.008Z",
		"size": 62737,
		"path": "../public/assets/karina-meneguini-retrato-C-w7w0_-.png"
	},
	"/assets/sponsor-ibicolor-6wigP9ca.png": {
		"type": "image/png",
		"etag": "\"6b3c-sICxTtuisbgloDhIpBm/hrnbRw0\"",
		"mtime": "2026-09-25T19:16:34.016Z",
		"size": 27452,
		"path": "../public/assets/sponsor-ibicolor-6wigP9ca.png"
	},
	"/assets/routes-BJG69hP8.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"14be9-1XuzrtyIqG9a3XujZyxdo1m3xag\"",
		"mtime": "2026-09-25T19:16:33.983Z",
		"size": 84969,
		"path": "../public/assets/routes-BJG69hP8.js"
	},
	"/assets/sponsor-emporio-qn-DB4gKVN6.png": {
		"type": "image/png",
		"etag": "\"15fc4-HRcng95NfIUk2lxa29f40E7ohCc\"",
		"mtime": "2026-09-25T19:16:34.011Z",
		"size": 90052,
		"path": "../public/assets/sponsor-emporio-qn-DB4gKVN6.png"
	},
	"/assets/sponsor-fernando-araujo-5nDgbAY5.png": {
		"type": "image/png",
		"etag": "\"11804-nub41wx6bh2oO6nPb4IG/zlol8I\"",
		"mtime": "2026-09-25T19:16:34.015Z",
		"size": 71684,
		"path": "../public/assets/sponsor-fernando-araujo-5nDgbAY5.png"
	},
	"/assets/sponsor-escola-aquarela-B8821YrV.png": {
		"type": "image/png",
		"etag": "\"72f4-x6ZIWK+Iu79RaxHZOQC9u1iPblY\"",
		"mtime": "2026-09-25T19:16:34.013Z",
		"size": 29428,
		"path": "../public/assets/sponsor-escola-aquarela-B8821YrV.png"
	},
	"/assets/sponsor-tia-lina-D5IfYmw6.png": {
		"type": "image/png",
		"etag": "\"58b4-NQGXDkubYShGQ9ZVy0rU+W7io+g\"",
		"mtime": "2026-09-25T19:16:34.020Z",
		"size": 22708,
		"path": "../public/assets/sponsor-tia-lina-D5IfYmw6.png"
	},
	"/assets/sponsor-jornal-da-economia-BQ-NLr5R.png": {
		"type": "image/png",
		"etag": "\"f95e-5eIPTYV6PaxnXJOydXIlKpZfsnk\"",
		"mtime": "2026-09-25T19:16:34.017Z",
		"size": 63838,
		"path": "../public/assets/sponsor-jornal-da-economia-BQ-NLr5R.png"
	},
	"/assets/sponsor-unimed-sao-roque-Dl8d23ks.png": {
		"type": "image/png",
		"etag": "\"3eaf-nPtM+OD7nFkzTvdUrK41y4dhcgg\"",
		"mtime": "2026-09-25T19:16:34.046Z",
		"size": 16047,
		"path": "../public/assets/sponsor-unimed-sao-roque-Dl8d23ks.png"
	},
	"/assets/sponsor-vila-don-patto-Dnnim9Hp.png": {
		"type": "image/png",
		"etag": "\"63c5-yzKVYehq0+a7dpdisdXTms7mxQw\"",
		"mtime": "2026-09-25T19:16:34.049Z",
		"size": 25541,
		"path": "../public/assets/sponsor-vila-don-patto-Dnnim9Hp.png"
	},
	"/assets/sponsor-rua-hum-CNvn9CY1.png": {
		"type": "image/png",
		"etag": "\"16e9e-q8EMNaqhg/rSeTKhUeDeGeBFd4U\"",
		"mtime": "2026-09-25T19:16:34.019Z",
		"size": 93854,
		"path": "../public/assets/sponsor-rua-hum-CNvn9CY1.png"
	},
	"/assets/sponsor-qualiser-contabilidade-X_g17cBt.png": {
		"type": "image/png",
		"etag": "\"f4e4-TSwEbqk9P+LEwLArAcgGnKN7g8s\"",
		"mtime": "2026-09-25T19:16:34.018Z",
		"size": 62692,
		"path": "../public/assets/sponsor-qualiser-contabilidade-X_g17cBt.png"
	},
	"/assets/ameas-acao-solidaria-BKXlWz6a.png": {
		"type": "image/png",
		"etag": "\"ae0fb-N2QqXKutPWWBjyF90/SOGhS72t0\"",
		"mtime": "2026-09-25T19:16:33.987Z",
		"size": 712955,
		"path": "../public/assets/ameas-acao-solidaria-BKXlWz6a.png"
	},
	"/assets/ameas-encontro-comunidade-C_5XCE8o.png": {
		"type": "image/png",
		"etag": "\"a8c4b-36FrvqSpfPjqOYQaLjn7Qr59NnI\"",
		"mtime": "2026-09-25T19:16:34.000Z",
		"size": 691275,
		"path": "../public/assets/ameas-encontro-comunidade-C_5XCE8o.png"
	},
	"/assets/ameas-crossfit-grupo-fmZO_tnE.png": {
		"type": "image/png",
		"etag": "\"97b88-+GmMJUicFLims6pIZ31bsWknGyI\"",
		"mtime": "2026-09-25T19:16:33.993Z",
		"size": 621448,
		"path": "../public/assets/ameas-crossfit-grupo-fmZO_tnE.png"
	},
	"/assets/ameas-acolhimento-cafe-DRcMIJ0T.png": {
		"type": "image/png",
		"etag": "\"d90bd-mOlSe76CcSsZuERbreyg1VEVo/k\"",
		"mtime": "2026-09-25T19:16:33.988Z",
		"size": 889021,
		"path": "../public/assets/ameas-acolhimento-cafe-DRcMIJ0T.png"
	},
	"/assets/index-BOuGRB67.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a42bf-x1PzQEf2QROWvKwoMNIal//0sw8\"",
		"mtime": "2026-09-25T19:16:33.981Z",
		"size": 672447,
		"path": "../public/assets/index-BOuGRB67.js"
	},
	"/assets/ameas-parceria-tia-lina-EULXuTE9.png": {
		"type": "image/png",
		"etag": "\"b28f7-4jaVPbuZ4P2fTbE3UDiWijlUZZQ\"",
		"mtime": "2026-09-25T19:16:34.005Z",
		"size": 731383,
		"path": "../public/assets/ameas-parceria-tia-lina-EULXuTE9.png"
	},
	"/assets/ameas-treino-adaptado-BZoWbuz_.png": {
		"type": "image/png",
		"etag": "\"d8295-rdvc2MfzoFqr7XRUjkc3xEVByrM\"",
		"mtime": "2026-09-25T19:16:34.007Z",
		"size": 885397,
		"path": "../public/assets/ameas-treino-adaptado-BZoWbuz_.png"
	},
	"/assets/ameas-parceiros-banner-qY4jQE2l.png": {
		"type": "image/png",
		"etag": "\"10dbf5-7RkXsHl4QSfTdDrC/lXRqxaPEdc\"",
		"mtime": "2026-09-25T19:16:34.003Z",
		"size": 1104885,
		"path": "../public/assets/ameas-parceiros-banner-qY4jQE2l.png"
	},
	"/assets/styles-DX4jW7TO.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"17ae8-DFmZHFh6nqYZBiVOPmSiZcoiv6Q\"",
		"mtime": "2026-09-25T19:16:34.053Z",
		"size": 97e3,
		"path": "../public/assets/styles-DX4jW7TO.css"
	}
};
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_RUfAHa = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_RUfAHa
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
[].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new FastResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function useNitroHooks() {
	const nitroApp = useNitroApp();
	const hooks = nitroApp.hooks;
	if (hooks) return hooks;
	return nitroApp.hooks = new HookableCore();
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/_module-handler.mjs
function createHandler(hooks) {
	const nitroApp = useNitroApp();
	const nitroHooks = useNitroHooks();
	return {
		async fetch(request, env, context) {
			globalThis.__env__ = env;
			augmentReq(request, {
				env,
				context
			});
			const ctxExt = {};
			const url = new URL(request.url);
			if (hooks.fetch) {
				const res = await hooks.fetch(request, env, context, url, ctxExt);
				if (res) return res;
			}
			return await nitroApp.fetch(request);
		},
		scheduled(controller, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:scheduled", {
				controller,
				env,
				context
			}) || Promise.resolve());
		},
		email(message, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:email", {
				message,
				event: message,
				env,
				context
			}) || Promise.resolve());
		},
		queue(batch, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:queue", {
				batch,
				event: batch,
				env,
				context
			}) || Promise.resolve());
		},
		tail(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:tail", {
				traces,
				env,
				context
			}) || Promise.resolve());
		},
		trace(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:trace", {
				traces,
				env,
				context
			}) || Promise.resolve());
		}
	};
}
function augmentReq(cfReq, ctx) {
	const req = cfReq;
	req.ip = cfReq.headers.get("cf-connecting-ip") || void 0;
	req.runtime ??= { name: "cloudflare" };
	req.runtime.cloudflare = {
		...req.runtime.cloudflare,
		...ctx
	};
	req.waitUntil = ctx.context?.waitUntil.bind(ctx.context);
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/cloudflare-module.mjs
var cloudflare_module_default = createHandler({ fetch(cfRequest, env, context, url) {
	if (env.ASSETS && isPublicAssetURL(url.pathname)) return env.ASSETS.fetch(cfRequest);
} });
//#endregion
export { cloudflare_module_default as default };
