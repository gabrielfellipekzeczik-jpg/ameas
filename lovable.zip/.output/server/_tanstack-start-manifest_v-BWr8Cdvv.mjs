//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BWr8Cdvv.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "C:/Users/Manserv/OneDrive - MANSERV/Área de Trabalho/AMEAS/src/routes/__root.tsx",
		children: ["/", "/admin"],
		preloads: ["/assets/index-DeENqrr5.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DeENqrr5.js"
		} }]
	},
	"/": {
		filePath: "C:/Users/Manserv/OneDrive - MANSERV/Área de Trabalho/AMEAS/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BJ38VL0G.js"]
	}
} });
//#endregion
export { tsrStartManifest };
