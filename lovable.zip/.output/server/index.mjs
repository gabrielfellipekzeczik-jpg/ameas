globalThis.__nitro_main__ = import.meta.url;
import { i as HTTPError, n as defineLazyEventHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { t as HookableCore } from "./_libs/hookable.mjs";
import { r as FastResponse } from "./_libs/h3-v2+rou3+srvx.mjs";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/favicon.png": {
		"type": "image/png",
		"etag": "\"ccb-Ew/dJ+NrT6tLxYxF4OVmdAb61sY\"",
		"mtime": "2026-09-23T12:06:04.697Z",
		"size": 3275,
		"path": "../public/favicon.png"
	},
	"/robots.txt": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"a0-CKGXSIe7TSsqDTmGm/nY1t/o5d0\"",
		"mtime": "2026-09-23T12:06:04.710Z",
		"size": 160,
		"path": "../public/robots.txt"
	},
	"/assets/ameas-logo-ByKQ8nTu.png": {
		"type": "image/png",
		"etag": "\"1592c-lVOPvYZiYV+UxIuo1pUwnT2UIxU\"",
		"mtime": "2026-09-23T16:38:50.941Z",
		"size": 88364,
		"path": "../public/assets/ameas-logo-ByKQ8nTu.png"
	},
	"/assets/ameas-corrida-adaptada-BaGPVSPR.png": {
		"type": "image/png",
		"etag": "\"4c422-V7YGHw8SuZBSrx8DeEdOdtQS+1E\"",
		"mtime": "2026-09-23T16:38:50.938Z",
		"size": 312354,
		"path": "../public/assets/ameas-corrida-adaptada-BaGPVSPR.png"
	},
	"/assets/routes-BJ38VL0G.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1331e-8Iwvhx4UIlHuzyPVPF7+gAGp1CQ\"",
		"mtime": "2026-09-23T16:38:50.929Z",
		"size": 78622,
		"path": "../public/assets/routes-BJ38VL0G.js"
	},
	"/assets/karina-meneguini-retrato-C-w7w0_-.png": {
		"type": "image/png",
		"etag": "\"f511-DnhDMvM3lV99Emnc9OGPkDc2C6g\"",
		"mtime": "2026-09-23T16:38:50.946Z",
		"size": 62737,
		"path": "../public/assets/karina-meneguini-retrato-C-w7w0_-.png"
	},
	"/assets/sponsor-emporio-qn-BRYsJHMB.png": {
		"type": "image/png",
		"etag": "\"7e78-ZOkoNRzada2IgTNPB8gBX/nECeg\"",
		"mtime": "2026-09-23T16:38:50.947Z",
		"size": 32376,
		"path": "../public/assets/sponsor-emporio-qn-BRYsJHMB.png"
	},
	"/assets/sponsor-fernando-araujo-BKuz5fN9.png": {
		"type": "image/png",
		"etag": "\"59eb-KttXIAg0TogXJ04MyqEG7XVuE3A\"",
		"mtime": "2026-09-23T16:38:50.949Z",
		"size": 23019,
		"path": "../public/assets/sponsor-fernando-araujo-BKuz5fN9.png"
	},
	"/assets/sponsor-ibicolor-g_BmEzOO.png": {
		"type": "image/png",
		"etag": "\"5f6c-40AVGrjcxs+z7/50z71n0R0TN0U\"",
		"mtime": "2026-09-23T16:38:50.950Z",
		"size": 24428,
		"path": "../public/assets/sponsor-ibicolor-g_BmEzOO.png"
	},
	"/assets/sponsor-tia-lina-BhlIPpDk.png": {
		"type": "image/png",
		"etag": "\"558b-zlPoPOoAHK5dkhCAeqWDXhP7rnc\"",
		"mtime": "2026-09-23T16:38:50.954Z",
		"size": 21899,
		"path": "../public/assets/sponsor-tia-lina-BhlIPpDk.png"
	},
	"/assets/sponsor-jornal-da-economia-B8m7275J.png": {
		"type": "image/png",
		"etag": "\"5b37-Z02EzAcSJqBGrh7e8Dgl3DPl2/s\"",
		"mtime": "2026-09-23T16:38:50.951Z",
		"size": 23351,
		"path": "../public/assets/sponsor-jornal-da-economia-B8m7275J.png"
	},
	"/assets/sponsor-escola-aquarela-CEKRCSWG.png": {
		"type": "image/png",
		"etag": "\"57fa-q/6T7Q2kXN+9QgoivV4+FFoLjDE\"",
		"mtime": "2026-09-23T16:38:50.948Z",
		"size": 22522,
		"path": "../public/assets/sponsor-escola-aquarela-CEKRCSWG.png"
	},
	"/assets/sponsor-rua-hum-qifzSStP.png": {
		"type": "image/png",
		"etag": "\"623a-5oJgMHcwEvFSTEVHIx3YUvO8iyU\"",
		"mtime": "2026-09-23T16:38:50.954Z",
		"size": 25146,
		"path": "../public/assets/sponsor-rua-hum-qifzSStP.png"
	},
	"/assets/sponsor-unimed-sao-roque-DnjVlxnp.png": {
		"type": "image/png",
		"etag": "\"5126-FRBLKO5FZO3f+Ra9ZRnV/+2DoME\"",
		"mtime": "2026-09-23T16:38:50.956Z",
		"size": 20774,
		"path": "../public/assets/sponsor-unimed-sao-roque-DnjVlxnp.png"
	},
	"/assets/styles-7VngkVGe.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"16c09-I1kkQ3cno4lD1L/NSWplwwfyFGw\"",
		"mtime": "2026-09-23T16:38:50.958Z",
		"size": 93193,
		"path": "../public/assets/styles-7VngkVGe.css"
	},
	"/assets/sponsor-qualiser-contabilidade-DbWYk4Ed.png": {
		"type": "image/png",
		"etag": "\"5b60-WCABwqrIqjlsDmPzcjvhucJzfOE\"",
		"mtime": "2026-09-23T16:38:50.953Z",
		"size": 23392,
		"path": "../public/assets/sponsor-qualiser-contabilidade-DbWYk4Ed.png"
	},
	"/assets/sponsor-vila-don-patto-Ct_LbHWE.png": {
		"type": "image/png",
		"etag": "\"4e6f-yCBJBSbvMd4etYD96KfVGJskVhc\"",
		"mtime": "2026-09-23T16:38:50.956Z",
		"size": 20079,
		"path": "../public/assets/sponsor-vila-don-patto-Ct_LbHWE.png"
	},
	"/assets/ameas-acao-solidaria-BKXlWz6a.png": {
		"type": "image/png",
		"etag": "\"ae0fb-N2QqXKutPWWBjyF90/SOGhS72t0\"",
		"mtime": "2026-09-23T16:38:50.934Z",
		"size": 712955,
		"path": "../public/assets/ameas-acao-solidaria-BKXlWz6a.png"
	},
	"/assets/ameas-crossfit-grupo-fmZO_tnE.png": {
		"type": "image/png",
		"etag": "\"97b88-+GmMJUicFLims6pIZ31bsWknGyI\"",
		"mtime": "2026-09-23T16:38:50.939Z",
		"size": 621448,
		"path": "../public/assets/ameas-crossfit-grupo-fmZO_tnE.png"
	},
	"/assets/ameas-encontro-comunidade-C_5XCE8o.png": {
		"type": "image/png",
		"etag": "\"a8c4b-36FrvqSpfPjqOYQaLjn7Qr59NnI\"",
		"mtime": "2026-09-23T16:38:50.940Z",
		"size": 691275,
		"path": "../public/assets/ameas-encontro-comunidade-C_5XCE8o.png"
	},
	"/assets/index-DeENqrr5.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9fa9e-xQiuGcpFdx9j9nUBhu+t/xx5QDg\"",
		"mtime": "2026-09-23T16:38:50.929Z",
		"size": 653982,
		"path": "../public/assets/index-DeENqrr5.js"
	},
	"/assets/ameas-acolhimento-cafe-DRcMIJ0T.png": {
		"type": "image/png",
		"etag": "\"d90bd-mOlSe76CcSsZuERbreyg1VEVo/k\"",
		"mtime": "2026-09-23T16:38:50.937Z",
		"size": 889021,
		"path": "../public/assets/ameas-acolhimento-cafe-DRcMIJ0T.png"
	},
	"/assets/ameas-parceria-tia-lina-EULXuTE9.png": {
		"type": "image/png",
		"etag": "\"b28f7-4jaVPbuZ4P2fTbE3UDiWijlUZZQ\"",
		"mtime": "2026-09-23T16:38:50.944Z",
		"size": 731383,
		"path": "../public/assets/ameas-parceria-tia-lina-EULXuTE9.png"
	},
	"/assets/ameas-treino-adaptado-BZoWbuz_.png": {
		"type": "image/png",
		"etag": "\"d8295-rdvc2MfzoFqr7XRUjkc3xEVByrM\"",
		"mtime": "2026-09-23T16:38:50.946Z",
		"size": 885397,
		"path": "../public/assets/ameas-treino-adaptado-BZoWbuz_.png"
	},
	"/assets/ameas-parceiros-banner-qY4jQE2l.png": {
		"type": "image/png",
		"etag": "\"10dbf5-7RkXsHl4QSfTdDrC/lXRqxaPEdc\"",
		"mtime": "2026-09-23T16:38:50.943Z",
		"size": 1104885,
		"path": "../public/assets/ameas-parceiros-banner-qY4jQE2l.png"
	}
};
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_h3o9Yy = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_h3o9Yy
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
[].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new FastResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function useNitroHooks() {
	const nitroApp = useNitroApp();
	const hooks = nitroApp.hooks;
	if (hooks) return hooks;
	return nitroApp.hooks = new HookableCore();
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/_module-handler.mjs
function createHandler(hooks) {
	const nitroApp = useNitroApp();
	const nitroHooks = useNitroHooks();
	return {
		async fetch(request, env, context) {
			globalThis.__env__ = env;
			augmentReq(request, {
				env,
				context
			});
			const ctxExt = {};
			const url = new URL(request.url);
			if (hooks.fetch) {
				const res = await hooks.fetch(request, env, context, url, ctxExt);
				if (res) return res;
			}
			return await nitroApp.fetch(request);
		},
		scheduled(controller, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:scheduled", {
				controller,
				env,
				context
			}) || Promise.resolve());
		},
		email(message, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:email", {
				message,
				event: message,
				env,
				context
			}) || Promise.resolve());
		},
		queue(batch, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:queue", {
				batch,
				event: batch,
				env,
				context
			}) || Promise.resolve());
		},
		tail(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:tail", {
				traces,
				env,
				context
			}) || Promise.resolve());
		},
		trace(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:trace", {
				traces,
				env,
				context
			}) || Promise.resolve());
		}
	};
}
function augmentReq(cfReq, ctx) {
	const req = cfReq;
	req.ip = cfReq.headers.get("cf-connecting-ip") || void 0;
	req.runtime ??= { name: "cloudflare" };
	req.runtime.cloudflare = {
		...req.runtime.cloudflare,
		...ctx
	};
	req.waitUntil = ctx.context?.waitUntil.bind(ctx.context);
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/cloudflare-module.mjs
var cloudflare_module_default = createHandler({ fetch(cfRequest, env, context, url) {
	if (env.ASSETS && isPublicAssetURL(url.pathname)) return env.ASSETS.fetch(cfRequest);
} });
//#endregion
export { cloudflare_module_default as default };
