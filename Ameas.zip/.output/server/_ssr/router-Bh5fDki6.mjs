import { n as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { a as ameas_crossfit_grupo_default, c as ameas_parceria_tia_lina_default, d as defaultGalleryCategories, f as defaultSiteContent, i as ameas_corrida_adaptada_default, l as ameas_treino_adaptado_default, n as ameas_acao_solidaria_default, o as ameas_encontro_comunidade_default, r as ameas_acolhimento_cafe_default, s as ameas_parceiros_banner_default, t as Button, u as cn, v as karina_meneguini_retrato_default, y as supabase } from "./ameas-treino-adaptado-B5-s9WZ7.mjs";
import { c as HeadContent, d as Outlet, f as lazyRouteComponent, g as useRouter, h as Link, m as createRootRouteWithContext, p as createFileRoute, s as Scripts, u as createRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as QueryClientProvider } from "../_libs/tanstack__react-query.mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
import { C as LayoutDashboard, D as Globe, E as HandHeart, S as Link2, _ as Moon, a as Trash2, c as Sun, d as Settings, f as Save, g as Pencil, h as Plus, j as CircleCheck, m as QrCode, r as Upload, s as Tag, t as X, w as ImagePlus, x as LogOut } from "../_libs/lucide-react.mjs";
import { t as Root } from "../_libs/radix-ui__react-label.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-Bh5fDki6.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var styles_default = "/assets/styles-DX4jW7TO.css";
function reportLovableError(error, context = {}) {
	if (typeof window === "undefined") return;
	window.__lovableEvents?.captureException?.(error, {
		source: "react_error_boundary",
		route: window.location.pathname,
		...context
	}, {
		mechanism: "react_error_boundary",
		handled: false,
		severity: "error"
	});
	const message = error instanceof Response ? `Response ${error.status}${error.url ? ` at ${error.url}` : ""}` : error instanceof Error ? error.message : String(error);
	const stack = error instanceof Error ? error.stack : void 0;
	window.__lovableReportRuntimeError?.({
		message,
		...stack !== void 0 && { stack },
		filename: window.location.pathname
	});
}
function NotFoundComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-7xl font-bold text-foreground",
					children: "404"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 text-xl font-semibold text-foreground",
					children: "Page not found"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "The page you're looking for doesn't exist or has been moved."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/",
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Go home"
					})
				})
			]
		})
	});
}
function ErrorComponent({ error, reset }) {
	console.error(error);
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		reportLovableError(error, { boundary: "tanstack_root_error_component" });
	}, [error]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-semibold tracking-tight text-foreground",
					children: "This page didn't load"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Something went wrong on our end. You can try refreshing or head back home."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap justify-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							router.invalidate();
							reset();
						},
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Try again"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/",
						className: "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent",
						children: "Go home"
					})]
				})
			]
		})
	});
}
var Route$2 = createRootRouteWithContext()({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "AMEAS" },
			{
				name: "description",
				content: "Associação Movimento Esporte Adaptado e Superação"
			},
			{
				name: "author",
				content: "AMEAS"
			},
			{
				property: "og:title",
				content: "AMEAS"
			},
			{
				property: "og:description",
				content: "Associação Movimento Esporte Adaptado e Superação"
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			},
			{
				name: "twitter:site",
				content: "@Lovable"
			}
		],
		links: [{
			rel: "stylesheet",
			href: styles_default
		}, {
			rel: "icon",
			href: "/favicon.png",
			type: "image/png"
		}]
	}),
	shellComponent: RootShell,
	component: RootComponent,
	notFoundComponent: NotFoundComponent,
	errorComponent: ErrorComponent
});
function RootShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "pt-BR",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("head", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("script", { dangerouslySetInnerHTML: { __html: `(function(){try{if(localStorage.getItem('ameas-theme')==='light'){document.documentElement.classList.add('light-mode');}}catch(e){}})();` } })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})] })]
	});
}
function RootComponent() {
	const { queryClient } = Route$2.useRouteContext();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryClientProvider, {
		client: queryClient,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
	});
}
var $$splitComponentImporter = () => import("./routes-Djsdjli0.mjs");
var Route$1 = createFileRoute("/")({
	head: () => ({ meta: [
		{ title: "AMEAS | Esporte Adaptado e Superação" },
		{
			name: "description",
			content: "Site institucional da AMEAS, associação que promove inclusão, acolhimento e superação por meio do esporte adaptado."
		},
		{
			property: "og:title",
			content: "AMEAS | Esporte Adaptado e Superação"
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
var Input = import_react.forwardRef(({ className, type, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		type,
		className: cn("flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-base shadow-sm transition-colors file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 md:text-sm", className),
		ref,
		...props
	});
});
Input.displayName = "Input";
var labelVariants = cva("text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70");
var Label = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Root, {
	ref,
	className: cn(labelVariants(), className),
	...props
}));
Label.displayName = Root.displayName;
var Textarea = import_react.forwardRef(({ className, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		className: cn("flex min-h-[60px] w-full rounded-md border border-input bg-transparent px-3 py-2 text-base shadow-sm placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 md:text-sm", className),
		ref,
		...props
	});
});
Textarea.displayName = "Textarea";
var Route = createFileRoute("/admin")({ component: AdminPage });
var ADMIN_LOGIN = "ameas";
var ADMIN_PASSWORD = "123456789";
var STATIC_GALLERY = [
	{
		src: ameas_corrida_adaptada_default,
		alt: "Atleta em triciclo adaptado",
		title: "Corrida adaptada",
		category: "esporte-adaptado"
	},
	{
		src: ameas_crossfit_grupo_default,
		alt: "Equipe AMEAS no CrossFit",
		title: "Treino coletivo",
		category: "esporte-adaptado"
	},
	{
		src: ameas_treino_adaptado_default,
		alt: "Treino adaptado",
		title: "Superacao em treino",
		category: "esporte-adaptado"
	},
	{
		src: ameas_encontro_comunidade_default,
		alt: "Grupo AMEAS reunido",
		title: "Encontro comunidade",
		category: "comunidade"
	},
	{
		src: ameas_acao_solidaria_default,
		alt: "Acao solidaria",
		title: "Acao solidaria",
		category: "comunidade"
	},
	{
		src: ameas_parceiros_banner_default,
		alt: "Banner parceiros",
		title: "Parceiros AMEAS",
		category: "comunidade"
	},
	{
		src: ameas_acolhimento_cafe_default,
		alt: "Cafe de acolhimento",
		title: "Cafe de acolhimento",
		category: "acolhimento"
	},
	{
		src: ameas_parceria_tia_lina_default,
		alt: "Parceria Tia Lina",
		title: "Parceria Tia Lina",
		category: "acolhimento"
	},
	{
		src: karina_meneguini_retrato_default,
		alt: "Karina Meneguini",
		title: "Karina Meneguini",
		category: "fundadora"
	}
];
var COLOR_PALETTE = [
	{
		label: "Azul",
		value: "bg-[#1B4B8A] text-white"
	},
	{
		label: "Vermelho",
		value: "bg-[#E8392A] text-white"
	},
	{
		label: "Verde",
		value: "bg-[#059669] text-white"
	},
	{
		label: "Roxo",
		value: "bg-[#7c3aed] text-white"
	},
	{
		label: "Laranja",
		value: "bg-[#f59e0b] text-black"
	},
	{
		label: "Rosa",
		value: "bg-[#db2777] text-white"
	},
	{
		label: "Ciano",
		value: "bg-[#0891b2] text-white"
	},
	{
		label: "Cinza",
		value: "bg-[#475569] text-white"
	}
];
function normalizeLogo(file) {
	return new Promise((resolve, reject) => {
		const img = new window.Image();
		img.onload = () => {
			const W = 400, H = 300;
			const canvas = document.createElement("canvas");
			canvas.width = W;
			canvas.height = H;
			const ctx = canvas.getContext("2d");
			ctx.fillStyle = "#ffffff";
			ctx.fillRect(0, 0, W, H);
			const scale = Math.min(352 / img.naturalWidth, 252 / img.naturalHeight);
			const w = Math.round(img.naturalWidth * scale);
			const h = Math.round(img.naturalHeight * scale);
			ctx.drawImage(img, Math.round((W - w) / 2), Math.round((H - h) / 2), w, h);
			resolve(canvas.toDataURL("image/png"));
			URL.revokeObjectURL(img.src);
		};
		img.onerror = () => reject(/* @__PURE__ */ new Error("Falha ao carregar imagem"));
		img.src = URL.createObjectURL(file);
	});
}
function normalizeGalleryImage(file) {
	return new Promise((resolve, reject) => {
		const img = new window.Image();
		img.onload = () => {
			const scale = Math.min(1200 / img.naturalWidth, 900 / img.naturalHeight, 1);
			const w = Math.round(img.naturalWidth * scale);
			const h = Math.round(img.naturalHeight * scale);
			const canvas = document.createElement("canvas");
			canvas.width = w;
			canvas.height = h;
			canvas.getContext("2d").drawImage(img, 0, 0, w, h);
			canvas.toBlob((b) => b ? resolve(b) : reject(/* @__PURE__ */ new Error("toBlob failed")), "image/jpeg", .88);
			URL.revokeObjectURL(img.src);
		};
		img.onerror = () => reject(/* @__PURE__ */ new Error("Falha ao carregar imagem"));
		img.src = URL.createObjectURL(file);
	});
}
var defaultPartnerLinks = [
	{
		slug: "rua-hum",
		name: "Rua Hum",
		website_url: "https://www.instagram.com/ruahum",
		sort_order: 1,
		published: true
	},
	{
		slug: "escola-aquarela",
		name: "Escola Aquarela",
		website_url: "https://www.instagram.com/escolaaquarelasr",
		sort_order: 2,
		published: true
	},
	{
		slug: "ibicolor",
		name: "Ibicolor",
		website_url: "https://www.instagram.com/ibicolor_sr",
		sort_order: 3,
		published: true
	},
	{
		slug: "vila-don-patto",
		name: "Vila Don Patto",
		website_url: "https://www.instagram.com/viladonpatto",
		sort_order: 4,
		published: true
	},
	{
		slug: "unimed-sao-roque",
		name: "Unimed Sao Roque",
		website_url: "https://www.unimed.coop.br/site/web/saoroque",
		sort_order: 5,
		published: true
	},
	{
		slug: "emporio-qn",
		name: "Emporio QN",
		website_url: "",
		sort_order: 6,
		published: true
	},
	{
		slug: "tia-lina",
		name: "Tia Lina",
		website_url: "https://www.instagram.com/cantinatialina",
		sort_order: 7,
		published: true
	},
	{
		slug: "fernando-araujo",
		name: "Fernando Araujo Artista Plastico",
		website_url: "https://www.instagram.com/araujoartistaplastico",
		sort_order: 8,
		published: true
	},
	{
		slug: "qualiser",
		name: "Qualiser Contabilidade",
		website_url: "",
		sort_order: 9,
		published: true
	},
	{
		slug: "jornal-da-economia",
		name: "Jornal da Economia",
		website_url: "",
		sort_order: 10,
		published: true
	}
];
function AdminPage() {
	const [loginInput, setLoginInput] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [isLoggedIn, setIsLoggedIn] = (0, import_react.useState)(false);
	const [content, setContent] = (0, import_react.useState)(defaultSiteContent);
	const [partnerLinks, setPartnerLinks] = (0, import_react.useState)(defaultPartnerLinks);
	const [logoMap, setLogoMap] = (0, import_react.useState)({});
	const [uploads, setUploads] = (0, import_react.useState)([]);
	const [uploadCategory, setUploadCategory] = (0, import_react.useState)("esporte-adaptado");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [msg, setMsg] = (0, import_react.useState)(null);
	const [loginError, setLoginError] = (0, import_react.useState)("");
	const [tab, setTab] = (0, import_react.useState)("hero");
	const [dbGallery, setDbGallery] = (0, import_react.useState)([]);
	const [loadingGallery, setLoadingGallery] = (0, import_react.useState)(false);
	const [categories, setCategories] = (0, import_react.useState)(defaultGalleryCategories);
	const [loadingCats, setLoadingCats] = (0, import_react.useState)(false);
	const [newCatLabel, setNewCatLabel] = (0, import_react.useState)("");
	const [newCatColor, setNewCatColor] = (0, import_react.useState)(COLOR_PALETTE[0].value);
	const [editingCat, setEditingCat] = (0, import_react.useState)(null);
	const [isLight, setIsLight] = (0, import_react.useState)(() => typeof window !== "undefined" && localStorage.getItem("ameas-theme") === "light");
	function toggleTheme() {
		const next = !isLight;
		setIsLight(next);
		document.documentElement.classList.toggle("light-mode", next);
		localStorage.setItem("ameas-theme", next ? "light" : "dark");
	}
	(0, import_react.useEffect)(() => {
		if (!isLoggedIn || !supabase) return;
		supabase.from("ameas_partners").select("slug,name,website_url,sort_order,published").order("sort_order").then(({ data }) => {
			if (data?.length) setPartnerLinks(data);
		});
		supabase.from("ameas_site_content").select("key,value").then(({ data }) => {
			if (!data) return;
			setContent(data.reduce((acc, row) => {
				if (row.key in acc) acc[row.key] = row.value;
				return acc;
			}, { ...defaultSiteContent }));
		});
	}, [isLoggedIn]);
	(0, import_react.useEffect)(() => {
		if (tab !== "galeria" || !isLoggedIn || !supabase) return;
		setLoadingGallery(true);
		setLoadingCats(true);
		supabase.from("ameas_gallery_items").select("id,title,alt,image_url,category,sort_order,published").order("sort_order").then(({ data }) => {
			setDbGallery(data ?? []);
			setLoadingGallery(false);
		});
		supabase.from("ameas_gallery_categories").select("id,label,color,sort_order").order("sort_order").then(({ data }) => {
			if (data?.length) setCategories(data);
			setLoadingCats(false);
		});
	}, [tab, isLoggedIn]);
	const uploadLabel = (0, import_react.useMemo)(() => `${uploads.length} ${uploads.length === 1 ? "arquivo" : "arquivos"}`, [uploads.length]);
	function login() {
		if (loginInput === ADMIN_LOGIN && password === ADMIN_PASSWORD) {
			setIsLoggedIn(true);
			setLoginError("");
		} else setLoginError("Login ou senha incorretos.");
	}
	function onKey(e) {
		if (e.key === "Enter") login();
	}
	function notify(text, ok = true) {
		setMsg({
			text,
			ok
		});
		setTimeout(() => setMsg(null), 4e3);
	}
	function set(k, v) {
		setContent((c) => ({
			...c,
			[k]: v
		}));
	}
	async function saveAll() {
		if (!supabase) return notify("Supabase nao configurado.", false);
		setBusy(true);
		const { error } = await supabase.from("ameas_site_content").upsert(Object.entries(content).map(([key, value]) => ({
			key,
			value
		})), { onConflict: "key" });
		setBusy(false);
		notify(error ? error.message : "Salvo com sucesso!", !error);
	}
	async function savePartners() {
		if (!supabase) return notify("Supabase nao configurado.", false);
		setBusy(true);
		const { error } = await supabase.from("ameas_partners").upsert(partnerLinks, { onConflict: "slug" });
		setBusy(false);
		notify(error ? error.message : "Parceiros salvos!", !error);
	}
	async function handleLogoFile(slug, file) {
		setLogoMap((prev) => ({
			...prev,
			[slug]: {
				file,
				preview: URL.createObjectURL(file),
				normalized: null,
				processing: true
			}
		}));
		try {
			const dataUrl = await normalizeLogo(file);
			setLogoMap((prev) => ({
				...prev,
				[slug]: {
					...prev[slug],
					normalized: dataUrl,
					processing: false
				}
			}));
		} catch {
			setLogoMap((prev) => {
				const n = { ...prev };
				delete n[slug];
				return n;
			});
			notify("Erro ao processar logo.", false);
		}
	}
	async function saveLogo(slug) {
		const item = logoMap[slug];
		if (!item?.normalized || !supabase) return notify("Processe a logo primeiro.", false);
		setBusy(true);
		const key = `logo_b64_${slug}`;
		const { error } = await supabase.from("ameas_site_content").upsert({
			key,
			value: item.normalized
		}, { onConflict: "key" });
		setBusy(false);
		if (error) return notify(`Erro: ${error.message}`, false);
		notify("Logo salva com sucesso!");
		setLogoMap((prev) => {
			const n = { ...prev };
			delete n[slug];
			return n;
		});
	}
	async function uploadImages() {
		if (!supabase || !uploads.length) return notify("Selecione pelo menos uma imagem.", false);
		setBusy(true);
		const errors = [];
		for (const { file } of uploads) {
			let blob;
			try {
				blob = await normalizeGalleryImage(file);
			} catch {
				blob = file;
			}
			const path = `gallery/${crypto.randomUUID()}-${file.name.replace(/[^a-z0-9._-]/gi, "-").replace(/\.[^.]+$/, "")}.jpg`;
			const up = await supabase.storage.from("ameas-site-media").upload(path, blob, {
				upsert: false,
				contentType: "image/jpeg"
			});
			if (up.error) {
				errors.push(up.error.message);
				continue;
			}
			const { data: urlData } = supabase.storage.from("ameas-site-media").getPublicUrl(path);
			const ins = await supabase.from("ameas_gallery_items").insert({
				title: file.name.replace(/\.[^.]+$/, ""),
				alt: "Imagem da AMEAS",
				image_url: urlData.publicUrl,
				category: uploadCategory,
				sort_order: 0,
				published: true
			});
			if (ins.error) errors.push(ins.error.message);
		}
		setBusy(false);
		if (errors.length) notify(errors.join(" | "), false);
		else {
			notify(`${uploads.length} imagem(ns) publicada(s)!`);
			setUploads([]);
		}
		supabase.from("ameas_gallery_items").select("id,title,alt,image_url,category,sort_order,published").order("sort_order").then(({ data }) => setDbGallery(data ?? []));
	}
	async function toggleGalleryPublished(item) {
		if (!supabase) return;
		const next = !item.published;
		setDbGallery((prev) => prev.map((g) => g.id === item.id ? {
			...g,
			published: next
		} : g));
		await supabase.from("ameas_gallery_items").update({ published: next }).eq("id", item.id);
	}
	async function updateGalleryCategory(item, category) {
		if (!supabase) return;
		setDbGallery((prev) => prev.map((g) => g.id === item.id ? {
			...g,
			category
		} : g));
		await supabase.from("ameas_gallery_items").update({ category }).eq("id", item.id);
	}
	async function deleteGalleryItem(item) {
		if (!supabase) return;
		setDbGallery((prev) => prev.filter((g) => g.id !== item.id));
		await supabase.from("ameas_gallery_items").delete().eq("id", item.id);
	}
	function slugify(label) {
		return label.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
	}
	async function createCategory() {
		if (!newCatLabel.trim() || !supabase) return notify("Digite um nome.", false);
		const id = slugify(newCatLabel);
		if (categories.some((c) => c.id === id)) return notify("Categoria ja existe.", false);
		const newCat = {
			id,
			label: newCatLabel.trim(),
			color: newCatColor,
			sort_order: categories.length + 1
		};
		setBusy(true);
		const { error } = await supabase.from("ameas_gallery_categories").insert(newCat);
		setBusy(false);
		if (error) return notify(error.message, false);
		setCategories((prev) => [...prev, newCat]);
		setNewCatLabel("");
		notify("Categoria criada!");
	}
	async function saveEditCategory() {
		if (!editingCat || !supabase) return;
		setBusy(true);
		const { error } = await supabase.from("ameas_gallery_categories").update({
			label: editingCat.label,
			color: editingCat.color
		}).eq("id", editingCat.id);
		setBusy(false);
		if (error) return notify(error.message, false);
		setCategories((prev) => prev.map((c) => c.id === editingCat.id ? editingCat : c));
		setEditingCat(null);
		notify("Categoria atualizada!");
	}
	async function deleteCategory(id) {
		if (!supabase) return;
		if (dbGallery.some((g) => g.category === id)) return notify("Remova as fotos dessa categoria primeiro.", false);
		setBusy(true);
		const { error } = await supabase.from("ameas_gallery_categories").delete().eq("id", id);
		setBusy(false);
		if (error) return notify(error.message, false);
		setCategories((prev) => prev.filter((c) => c.id !== id));
		notify("Categoria removida.");
	}
	if (!isLoggedIn) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "relative flex min-h-screen items-center justify-center overflow-hidden bg-background px-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute -top-40 left-1/2 h-96 w-96 -translate-x-1/2 rounded-full bg-[#1B4B8A]/20 blur-3xl" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute bottom-0 right-0 h-72 w-72 rounded-full bg-[#E8392A]/10 blur-3xl" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "glass-blue relative w-full max-w-sm overflow-hidden rounded-3xl border border-[#1B4B8A]/30 p-8 shadow-2xl backdrop-blur",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-6 text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl border border-[#1B4B8A]/40 bg-[#1B4B8A]/15 glow-blue",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LayoutDashboard, { className: "h-6 w-6 text-[#7eb5f5]" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "gradient-text text-2xl font-black",
							children: "Painel AMEAS"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-foreground/50",
							children: "Area restrita"
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "login",
								className: "text-xs font-bold uppercase tracking-wide text-foreground/50",
								children: "Login"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "login",
								type: "text",
								value: loginInput,
								onChange: (e) => setLoginInput(e.target.value),
								onKeyDown: onKey,
								placeholder: "ameas",
								autoComplete: "username",
								className: "rounded-2xl border-border/40 bg-white/5 text-foreground placeholder:text-foreground/30"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "pw",
								className: "text-xs font-bold uppercase tracking-wide text-foreground/50",
								children: "Senha"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "pw",
								type: "password",
								value: password,
								onChange: (e) => setPassword(e.target.value),
								onKeyDown: onKey,
								autoComplete: "current-password",
								className: "rounded-2xl border-border/40 bg-white/5 text-foreground placeholder:text-foreground/30"
							})]
						}),
						loginError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "rounded-2xl border border-red-500/20 bg-red-500/10 px-4 py-2.5 text-sm text-red-400",
							children: loginError
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: login,
							className: "w-full rounded-2xl bg-[#1B4B8A] text-white shadow-lg shadow-[#1B4B8A]/30 hover:bg-[#1B4B8A]/90",
							children: "Entrar"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/",
							className: "block text-center text-sm text-foreground/40 hover:text-[#7eb5f5] transition-colors",
							children: "← Voltar ao site"
						})
					]
				})]
			})
		]
	});
	const tabs = [
		{
			id: "hero",
			label: "Hero / Sobre",
			icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, { className: "h-4 w-4" })
		},
		{
			id: "depoimentos",
			label: "Depoimentos",
			icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-4 w-4" })
		},
		{
			id: "pix",
			label: "PIX",
			icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QrCode, { className: "h-4 w-4" })
		},
		{
			id: "voluntario",
			label: "Voluntario",
			icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HandHeart, { className: "h-4 w-4" })
		},
		{
			id: "parceiros",
			label: "Parceiros",
			icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link2, { className: "h-4 w-4" })
		},
		{
			id: "galeria",
			label: "Galeria",
			icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, { className: "h-4 w-4" })
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "min-h-screen bg-background text-foreground",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "sticky top-0 z-40 border-b border-border/30 bg-background/85 backdrop-blur-2xl",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-7xl items-center justify-between px-4 py-3 sm:px-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex h-9 w-9 items-center justify-center rounded-xl border border-[#1B4B8A]/30 bg-[#1B4B8A]/10 glow-blue",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LayoutDashboard, { className: "h-4 w-4 text-[#7eb5f5]" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[10px] font-black uppercase tracking-widest text-[#7eb5f5]/70",
							children: "AMEAS CMS"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-black text-foreground",
							children: "Painel administrativo"
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/",
								className: "hidden rounded-xl border border-border/40 px-3 py-1.5 text-xs font-semibold text-foreground/50 hover:text-[#7eb5f5] sm:block transition-colors",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Globe, { className: "inline h-3.5 w-3.5 mr-1" }), "Ver site"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: toggleTheme,
								className: "flex items-center gap-1.5 rounded-xl border border-border/40 px-3 py-1.5 text-xs font-semibold text-foreground/60 transition-all hover:border-[#1B4B8A]/40 hover:text-[#7eb5f5]",
								children: [isLight ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, { className: "h-3.5 w-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, { className: "h-3.5 w-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "hidden sm:inline",
									children: isLight ? "Escuro" : "Claro"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "ghost",
								size: "sm",
								onClick: () => setIsLoggedIn(false),
								className: "rounded-xl border border-border/30 text-xs text-foreground/50 hover:text-red-400 hover:border-red-500/30",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "mr-1.5 h-3.5 w-3.5" }), " Sair"]
							})
						]
					})]
				})
			}),
			msg && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: `fixed right-5 top-20 z-50 flex items-center gap-2 rounded-2xl border px-4 py-3 text-sm font-semibold shadow-xl backdrop-blur ${msg.ok ? "border-emerald-500/30 bg-emerald-500/15 text-emerald-400" : "border-red-500/30 bg-red-500/15 text-red-400"}`,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-4 w-4 shrink-0" }),
					" ",
					msg.text
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-7xl px-4 py-8 sm:px-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mb-6 grid gap-3 sm:grid-cols-4",
						children: [
							{
								label: "Status",
								value: "Publicado",
								color: "text-emerald-400"
							},
							{
								label: "Admin",
								value: "ameas",
								color: "text-[#7eb5f5]"
							},
							{
								label: "Parceiros",
								value: `${partnerLinks.length}`,
								color: "text-[#38bdf8]"
							},
							{
								label: "Fotos",
								value: uploadLabel,
								color: "text-[#f59e0b]"
							}
						].map(({ label, value, color }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "glass rounded-2xl border border-border/30 p-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-foreground/40",
								children: label
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: `mt-1 text-base font-black ${color}`,
								children: value
							})]
						}, label))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mb-6 overflow-x-auto",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex min-w-max gap-1 rounded-2xl border border-border/30 bg-secondary/30 p-1",
							children: tabs.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: () => setTab(t.id),
								className: `flex items-center gap-1.5 rounded-xl px-3 py-2 text-xs font-bold whitespace-nowrap transition-all ${tab === t.id ? "bg-[#1B4B8A]/25 text-[#7eb5f5] border border-[#1B4B8A]/30 glow-blue" : "text-foreground/50 hover:text-foreground"}`,
								children: [
									t.icon,
									" ",
									t.label
								]
							}, t.id))
						})
					}),
					tab === "hero" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminCard, {
							title: "Hero e Sobre",
							desc: "Textos principais da pagina inicial.",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-5 sm:grid-cols-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
										label: "Titulo do hero",
										value: content.hero_title,
										onChange: (v) => set("hero_title", v)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
										label: "WhatsApp",
										value: content.contact_whatsapp,
										onChange: (v) => set("contact_whatsapp", v)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "sm:col-span-2",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
											label: "Subtitulo",
											value: content.hero_subtitle,
											onChange: (v) => set("hero_subtitle", v),
											multi: true
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "sm:col-span-2",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
											label: "Sobre a AMEAS",
											value: content.about_text,
											onChange: (v) => set("about_text", v),
											multi: true
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
										label: "Instagram URL",
										value: content.instagram_url,
										onChange: (v) => set("instagram_url", v)
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SaveBtn, {
								onClick: saveAll,
								busy
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminCard, {
							title: "Fundadora",
							desc: "Nome e biografia exibidos na secao da fundadora.",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
										label: "Nome",
										value: content.founder_name,
										onChange: (v) => set("founder_name", v)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
										label: "Biografia 1",
										value: content.founder_bio1,
										onChange: (v) => set("founder_bio1", v),
										multi: true
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
										label: "Biografia 2",
										value: content.founder_bio2,
										onChange: (v) => set("founder_bio2", v),
										multi: true
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SaveBtn, {
								onClick: saveAll,
								busy
							})]
						})]
					}),
					tab === "depoimentos" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminCard, {
						title: "Depoimentos",
						desc: "Tres depoimentos da secao de vozes.",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "space-y-6",
							children: [
								1,
								2,
								3
							].map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-2xl border border-border/20 bg-secondary/20 p-5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mb-3 text-xs font-black uppercase tracking-widest text-foreground/40",
									children: ["Depoimento ", n]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid gap-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
										label: "Citacao",
										value: content[`test${n}_quote`],
										onChange: (v) => set(`test${n}_quote`, v),
										multi: true
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
										label: "Autor",
										value: content[`test${n}_author`],
										onChange: (v) => set(`test${n}_author`, v)
									})]
								})]
							}, n))
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SaveBtn, {
							onClick: saveAll,
							busy
						})]
					}),
					tab === "pix" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminCard, {
						title: "PIX e Doacao",
						desc: "Dados bancarios e codigos copia-e-cola por valor.",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-5 sm:grid-cols-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "sm:col-span-2",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
										label: "Chave PIX (CNPJ)",
										value: content.pix_key,
										onChange: (v) => set("pix_key", v)
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
									label: "Banco",
									value: content.pix_bank,
									onChange: (v) => set("pix_bank", v)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
									label: "Agencia",
									value: content.pix_agency,
									onChange: (v) => set("pix_agency", v)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
									label: "Conta",
									value: content.pix_account,
									onChange: (v) => set("pix_account", v)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "sm:col-span-2 border-t border-border/20 pt-5 space-y-4",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm font-black text-foreground",
											children: "Codigos PIX por valor"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "rounded-2xl border border-[#1B4B8A]/20 bg-[#1B4B8A]/5 p-4 space-y-4",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PixCodeField, {
													label: "Apoiador Mensal R$30",
													value: content.pix_monthly,
													onChange: (v) => set("pix_monthly", v)
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PixCodeField, {
													label: "R$ 25",
													value: content.pix_25,
													onChange: (v) => set("pix_25", v)
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PixCodeField, {
													label: "R$ 50",
													value: content.pix_50,
													onChange: (v) => set("pix_50", v)
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PixCodeField, {
													label: "R$ 100",
													value: content.pix_100,
													onChange: (v) => set("pix_100", v)
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PixCodeField, {
													label: "R$ 200",
													value: content.pix_200,
													onChange: (v) => set("pix_200", v)
												})
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											className: "text-xs font-black uppercase tracking-wide text-foreground/50",
											children: "Codigo generico / valor livre"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
											value: content.pix_copypaste,
											onChange: (e) => set("pix_copypaste", e.target.value),
											rows: 3,
											placeholder: "00020126...",
											className: "mt-1.5 rounded-xl border-border/30 bg-white/5 text-foreground placeholder:text-foreground/30 resize-none font-mono text-xs"
										})] })
									]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SaveBtn, {
							onClick: saveAll,
							busy
						})]
					}),
					tab === "voluntario" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminCard, {
						title: "Secao Voluntario",
						desc: "Titulo e descricao do card de voluntariado.",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
								label: "Titulo",
								value: content.volunteer_title,
								onChange: (v) => set("volunteer_title", v)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
								label: "Descricao",
								value: content.volunteer_desc,
								onChange: (v) => set("volunteer_desc", v),
								multi: true
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SaveBtn, {
							onClick: saveAll,
							busy
						})]
					}),
					tab === "parceiros" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminCard, {
						title: "Parceiros",
						desc: "Link, visibilidade e logo de cada apoiador. A logo e salva e exibida no site automaticamente.",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "space-y-3",
							children: partnerLinks.map((p, i) => {
								const logoState = logoMap[p.slug];
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-2xl border border-border/20 bg-secondary/20 p-4 space-y-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid items-center gap-3 sm:grid-cols-[160px_1fr_auto]",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs font-black text-foreground/80",
												children: p.name
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-[10px] text-foreground/40 uppercase tracking-wide",
												children: p.slug
											})] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												type: "url",
												placeholder: "https://...",
												value: p.website_url,
												onChange: (e) => setPartnerLinks(partnerLinks.map((x, j) => j === i ? {
													...x,
													website_url: e.target.value
												} : x)),
												className: "rounded-xl border-border/30 bg-white/5 text-sm text-foreground placeholder:text-foreground/30"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												onClick: () => setPartnerLinks(partnerLinks.map((x, j) => j === i ? {
													...x,
													published: !x.published
												} : x)),
												className: `rounded-xl border px-3 py-1.5 text-xs font-bold transition-all ${p.published ? "border-emerald-500/30 bg-emerald-500/15 text-emerald-400" : "border-border/30 text-foreground/40"}`,
												children: p.published ? "Visivel" : "Oculto"
											})
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogoRow, {
										slug: p.slug,
										state: logoState ?? null,
										onFile: (file) => handleLogoFile(p.slug, file),
										onRemove: () => setLogoMap((prev) => {
											const n = { ...prev };
											delete n[p.slug];
											return n;
										}),
										onSave: () => saveLogo(p.slug),
										busy
									})]
								}, p.slug);
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							onClick: savePartners,
							disabled: busy,
							className: "mt-6 rounded-2xl bg-[#1B4B8A] text-white hover:bg-[#1B4B8A]/90",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, { className: "mr-2 h-4 w-4" }),
								" ",
								busy ? "Salvando..." : "Salvar links"
							]
						})]
					}),
					tab === "galeria" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-8",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminCard, {
								title: "Categorias de Eventos",
								desc: "Crie, edite ou remova categorias. Aparecem como eventos na galeria do site.",
								children: [loadingCats ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "py-4 text-center text-sm text-foreground/40 animate-pulse",
									children: "Carregando..."
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "space-y-3",
									children: categories.map((cat) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "flex flex-wrap items-center gap-3 rounded-2xl border border-border/20 bg-secondary/20 p-3",
										children: editingCat?.id === cat.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												value: editingCat.label,
												onChange: (e) => setEditingCat({
													...editingCat,
													label: e.target.value
												}),
												className: "h-8 flex-1 min-w-[140px] rounded-xl border-border/30 bg-white/5 text-sm text-foreground"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "flex flex-wrap gap-1.5",
												children: COLOR_PALETTE.map((cp) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													onClick: () => setEditingCat({
														...editingCat,
														color: cp.value
													}),
													title: cp.label,
													className: `h-6 w-6 rounded-full border-2 transition-transform hover:scale-110 ${cp.value.split(" ")[0]} ${editingCat.color === cp.value ? "border-white scale-110" : "border-transparent"}`
												}, cp.value))
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
												size: "sm",
												onClick: saveEditCategory,
												disabled: busy,
												className: "h-8 rounded-xl bg-[#1B4B8A] text-white text-xs px-3",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, { className: "h-3 w-3 mr-1" }), "Salvar"]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
												size: "sm",
												variant: "ghost",
												onClick: () => setEditingCat(null),
												className: "h-8 rounded-xl text-xs text-foreground/50 px-3",
												children: "Cancelar"
											})
										] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: `rounded-full px-3 py-1 text-xs font-black uppercase tracking-wide ${cat.color}`,
												children: cat.label
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[10px] text-foreground/40 font-mono",
												children: cat.id
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-[10px] text-foreground/30 ml-auto",
												children: [dbGallery.filter((g) => g.category === cat.id).length, " foto(s)"]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												onClick: () => setEditingCat(cat),
												className: "flex items-center gap-1 rounded-xl border border-border/30 px-2.5 py-1.5 text-[10px] font-bold text-foreground/50 hover:text-[#7eb5f5] hover:border-[#1B4B8A]/40 transition-all",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "h-3 w-3" }), "Editar"]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												onClick: () => deleteCategory(cat.id),
												className: "flex items-center gap-1 rounded-xl border border-red-500/20 bg-red-500/5 px-2.5 py-1.5 text-[10px] font-bold text-red-400 hover:bg-red-500/15 transition-all",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-3 w-3" }), "Excluir"]
											})
										] })
									}, cat.id))
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-6 rounded-2xl border border-[#1B4B8A]/20 bg-[#1B4B8A]/5 p-5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mb-4 text-sm font-black text-foreground flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4 text-[#7eb5f5]" }), "Nova categoria"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-wrap items-end gap-3",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex-1 min-w-[160px]",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
													className: "text-[10px] font-black uppercase tracking-wide text-foreground/50",
													children: "Nome"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													value: newCatLabel,
													onChange: (e) => setNewCatLabel(e.target.value),
													placeholder: "Ex: Corrida de Rua",
													onKeyDown: (e) => e.key === "Enter" && createCategory(),
													className: "mt-1 rounded-xl border-border/30 bg-white/5 text-foreground placeholder:text-foreground/30"
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
												className: "text-[10px] font-black uppercase tracking-wide text-foreground/50",
												children: "Cor"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "mt-1.5 flex flex-wrap gap-1.5",
												children: COLOR_PALETTE.map((cp) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													onClick: () => setNewCatColor(cp.value),
													title: cp.label,
													className: `h-7 w-7 rounded-full border-2 transition-transform hover:scale-110 ${cp.value.split(" ")[0]} ${newCatColor === cp.value ? "border-white scale-110" : "border-transparent"}`
												}, cp.value))
											})] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
												className: "text-[10px] font-black uppercase tracking-wide text-foreground/50",
												children: "Preview"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: `mt-1.5 inline-block rounded-full px-3 py-1 text-xs font-black uppercase tracking-wide ${newCatColor}`,
												children: newCatLabel || "Nome"
											})] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
												onClick: createCategory,
												disabled: busy || !newCatLabel.trim(),
												className: "rounded-2xl bg-[#1B4B8A] text-white hover:bg-[#1B4B8A]/90",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "mr-1.5 h-4 w-4" }), busy ? "Criando..." : "Criar"]
											})
										]
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminCard, {
								title: "Adicionar Fotos",
								desc: "Escolha a categoria e envie as imagens. Redimensionadas automaticamente.",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mb-5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "mb-2 text-xs font-black uppercase tracking-wide text-foreground/50 flex items-center gap-1.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tag, { className: "h-3.5 w-3.5" }), " Categoria"]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "flex flex-wrap gap-2",
											children: categories.map((ev) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												onClick: () => setUploadCategory(ev.id),
												className: `rounded-full px-4 py-1.5 text-xs font-black uppercase tracking-wide transition-all border ${uploadCategory === ev.id ? `${ev.color} border-transparent shadow` : "border-border/30 text-foreground/50 hover:text-foreground"}`,
												children: ev.label
											}, ev.id))
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "flex min-h-36 cursor-pointer flex-col items-center justify-center rounded-2xl border-2 border-dashed border-[#1B4B8A]/30 bg-[#1B4B8A]/5 p-8 text-center transition hover:border-[#1B4B8A]/60 hover:bg-[#1B4B8A]/10",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "mb-3 h-8 w-8 text-[#7eb5f5]" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-black text-foreground",
												children: "Clique para selecionar fotos"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "mt-1 text-sm text-foreground/50",
												children: "PNG, JPG ou WEBP"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												type: "file",
												accept: "image/png,image/jpeg,image/webp",
												multiple: true,
												className: "sr-only",
												onChange: (e) => setUploads(Array.from(e.target.files ?? []).map((f) => ({
													file: f,
													url: URL.createObjectURL(f)
												})))
											})
										]
									}),
									uploads.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "mt-5 grid grid-cols-3 gap-3 sm:grid-cols-5 lg:grid-cols-8",
											children: uploads.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "group relative aspect-square overflow-hidden rounded-xl",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
													src: item.url,
													alt: item.file.name,
													className: "h-full w-full object-cover"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													onClick: () => setUploads(uploads.filter((u) => u.url !== item.url)),
													className: "absolute right-1 top-1 flex h-5 w-5 items-center justify-center rounded-full bg-red-500/80 text-white opacity-0 transition group-hover:opacity-100",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-3 w-3" })
												})]
											}, item.url))
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mt-4 flex items-center gap-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-xs text-foreground/50",
												children: "Publicar em:"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: `rounded-full px-3 py-1 text-xs font-black uppercase tracking-wide ${categories.find((e) => e.id === uploadCategory)?.color ?? ""}`,
												children: categories.find((e) => e.id === uploadCategory)?.label ?? uploadCategory
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
											onClick: uploadImages,
											disabled: busy,
											className: "mt-4 rounded-2xl bg-[#1B4B8A] text-white hover:bg-[#1B4B8A]/90",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "mr-2 h-4 w-4" }),
												" ",
												busy ? "Enviando..." : `Publicar ${uploads.length} imagem(ns)`
											]
										})
									] })
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminCard, {
								title: "Fotos do Site",
								desc: "Imagens do codigo-fonte, por evento.",
								children: categories.map((ev) => {
									const items = STATIC_GALLERY.filter((g) => g.category === ev.id);
									if (!items.length) return null;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mb-6 last:mb-0",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "mb-3 flex items-center gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: `rounded-full px-3 py-1 text-[11px] font-black uppercase tracking-wide ${ev.color}`,
												children: ev.label
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-xs text-foreground/40",
												children: [
													items.length,
													" foto",
													items.length !== 1 ? "s" : ""
												]
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "grid grid-cols-3 gap-3 sm:grid-cols-4 lg:grid-cols-6",
											children: items.map((img) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "group relative aspect-[4/3] overflow-hidden rounded-xl border border-border/20",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
													src: img.src,
													alt: img.alt,
													className: "h-full w-full object-cover",
													loading: "lazy"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "absolute inset-0 flex items-end bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity p-2",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
														className: "text-[10px] font-bold text-white leading-tight",
														children: img.title
													})
												})]
											}, img.src))
										})]
									}, ev.id);
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminCard, {
								title: "Fotos do Supabase",
								desc: "Imagens enviadas pelo admin. Altere a categoria, oculte ou exclua.",
								children: loadingGallery ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "py-8 text-center text-sm text-foreground/40 animate-pulse",
									children: "Carregando..."
								}) : dbGallery.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "py-8 text-center text-sm text-foreground/40",
									children: "Nenhuma imagem publicada ainda."
								}) : categories.map((ev) => {
									const items = dbGallery.filter((g) => g.category === ev.id);
									const uncategorised = ev.id === categories[0]?.id ? dbGallery.filter((g) => !g.category) : [];
									const all = [...items, ...uncategorised];
									if (!all.length) return null;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mb-6 last:mb-0",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "mb-3 flex items-center gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: `rounded-full px-3 py-1 text-[11px] font-black uppercase tracking-wide ${ev.color}`,
												children: ev.label
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-xs text-foreground/40",
												children: [
													all.length,
													" foto",
													all.length !== 1 ? "s" : ""
												]
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5",
											children: all.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "overflow-hidden rounded-xl border border-border/20 bg-secondary/20",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "aspect-[4/3] overflow-hidden",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
														src: item.image_url,
														alt: item.alt,
														className: "h-full w-full object-cover",
														loading: "lazy"
													})
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "p-2 space-y-1.5",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
															className: "text-[10px] font-bold text-foreground/70 truncate",
															children: item.title
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
															value: item.category ?? "",
															onChange: (e) => updateGalleryCategory(item, e.target.value),
															className: "w-full rounded-lg border border-border/30 bg-background/60 px-2 py-1 text-[10px] text-foreground/70 focus:outline-none",
															children: categories.map((ec) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
																value: ec.id,
																children: ec.label
															}, ec.id))
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "flex gap-1",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
																onClick: () => toggleGalleryPublished(item),
																className: `flex-1 rounded-lg border px-2 py-1 text-[10px] font-bold transition-all ${item.published ? "border-emerald-500/30 bg-emerald-500/15 text-emerald-400" : "border-border/30 text-foreground/40"}`,
																children: item.published ? "Visivel" : "Oculto"
															}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
																onClick: () => deleteGalleryItem(item),
																className: "rounded-lg border border-red-500/20 bg-red-500/10 px-2 py-1 text-red-400 hover:bg-red-500/20 transition-all",
																children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-3 w-3" })
															})]
														})
													]
												})]
											}, item.id))
										})]
									}, ev.id);
								})
							})
						]
					})
				]
			})
		]
	});
}
function LogoRow({ slug, state, onFile, onRemove, onSave, busy }) {
	const inputRef = (0, import_react.useRef)(null);
	if (!state) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		onClick: () => inputRef.current?.click(),
		className: "flex items-center gap-1.5 rounded-xl border border-border/30 px-3 py-1.5 text-[11px] font-bold text-foreground/40 hover:text-[#7eb5f5] hover:border-[#1B4B8A]/40 transition-all w-fit",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "h-3 w-3" }),
			"Trocar logo",
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				ref: inputRef,
				type: "file",
				accept: "image/png,image/jpeg,image/webp,image/svg+xml",
				className: "sr-only",
				onChange: (e) => {
					const f = e.target.files?.[0];
					if (f) onFile(f);
					e.target.value = "";
				}
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-wrap items-center gap-3 rounded-xl border border-border/20 bg-background/30 p-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[9px] font-black uppercase text-foreground/30 mb-1",
				children: "Original"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "h-16 w-24 flex items-center justify-center rounded-lg overflow-hidden bg-background/40 border border-border/20",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: state.preview,
					alt: "original",
					className: "max-h-full max-w-full object-contain"
				})
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[9px] font-black uppercase text-foreground/30 mb-1",
				children: "Normalizada 400x300"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "h-16 w-24 flex items-center justify-center rounded-lg overflow-hidden bg-white border border-border/20",
				children: state.processing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-[9px] text-foreground/40 animate-pulse",
					children: "Processando..."
				}) : state.normalized ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: state.normalized,
					alt: "normalizada",
					className: "max-h-full max-w-full object-contain"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-[9px] text-red-400",
					children: "Erro"
				})
			})] })]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex gap-2 ml-auto",
			children: [
				state.normalized && !state.processing && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					onClick: onSave,
					disabled: busy,
					className: "h-8 rounded-xl bg-emerald-600 text-white hover:bg-emerald-600/90 text-xs px-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, { className: "h-3 w-3 mr-1" }), busy ? "Salvando..." : "Salvar logo"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: onRemove,
					className: "flex items-center gap-1 h-8 rounded-xl border border-red-500/30 bg-red-500/10 px-3 text-[11px] font-bold text-red-400 hover:bg-red-500/20 transition-all",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-3 w-3" }), "Cancelar"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: () => inputRef.current?.click(),
					className: "flex items-center gap-1 h-8 rounded-xl border border-border/30 px-3 text-[11px] font-bold text-foreground/50 hover:text-[#7eb5f5] hover:border-[#1B4B8A]/40 transition-all",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "h-3 w-3" }), "Trocar"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					ref: inputRef,
					type: "file",
					accept: "image/png,image/jpeg,image/webp,image/svg+xml",
					className: "sr-only",
					onChange: (e) => {
						const f = e.target.files?.[0];
						if (f) onFile(f);
						e.target.value = "";
					}
				})
			]
		})]
	});
}
function AdminCard({ title, desc, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "glass rounded-3xl border border-border/30 p-6 sm:p-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-lg font-black text-foreground",
				children: title
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-foreground/50",
				children: desc
			})]
		}), children]
	});
}
function SaveBtn({ onClick, busy }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
		onClick,
		disabled: busy,
		className: "mt-6 rounded-2xl bg-[#1B4B8A] text-white hover:bg-[#1B4B8A]/90",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, { className: "mr-2 h-4 w-4" }),
			" ",
			busy ? "Salvando..." : "Salvar"
		]
	});
}
function F({ label, value, onChange, multi = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-1.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
			className: "text-xs font-bold uppercase tracking-wide text-foreground/50",
			children: label
		}), multi ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
			value,
			onChange: (e) => onChange(e.target.value),
			rows: 3,
			className: "rounded-xl border-border/30 bg-white/5 text-foreground resize-none"
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
			value,
			onChange: (e) => onChange(e.target.value),
			className: "rounded-xl border-border/30 bg-white/5 text-foreground"
		})]
	});
}
function PixCodeField({ label, value, onChange }) {
	const [show, setShow] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-1",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
				className: "text-xs font-bold uppercase tracking-wide text-foreground/50",
				children: label
			}), value && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "rounded-full border border-emerald-500/30 bg-emerald-500/15 px-2 py-0.5 text-[10px] font-black text-emerald-400",
				children: "Preenchido"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
			value,
			onChange: (e) => onChange(e.target.value),
			rows: show ? 3 : 1,
			onFocus: () => setShow(true),
			onBlur: () => setShow(false),
			placeholder: "00020126...",
			className: "w-full resize-none rounded-xl border border-border/30 bg-white/5 px-3 py-2 font-mono text-xs text-foreground placeholder:text-foreground/30 focus:outline-none focus:ring-1 focus:ring-[#1B4B8A]/60 transition-all"
		})]
	});
}
var rootRouteChildren = {
	IndexRoute: Route$1.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$2
	}),
	AdminRoute: Route.update({
		id: "/admin",
		path: "/admin",
		getParentRoute: () => Route$2
	})
};
var routeTree = Route$2._addFileChildren(rootRouteChildren)._addFileTypes();
function getRouter() {
	const queryClient = new QueryClient();
	return createRouter({
		routeTree,
		context: { queryClient },
		defaultPreload: "intent",
		scrollRestoration: true
	});
}
//#endregion
export { getRouter };
