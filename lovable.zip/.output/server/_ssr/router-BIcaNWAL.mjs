import { n as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { n as cn, o as supabase, r as defaultSiteContent, t as Button } from "./supabase-D734pmWn.mjs";
import { c as HeadContent, d as Outlet, f as lazyRouteComponent, g as useRouter, h as Link, m as createRootRouteWithContext, p as createFileRoute, s as Scripts, u as createRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as QueryClientProvider } from "../_libs/tanstack__react-query.mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
import { C as Globe, D as CircleCheck, S as HandHeart, _ as LogOut, b as ImagePlus, f as QrCode, l as Settings, n as Users, o as Sun, p as Moon, r as Upload, t as X, u as Save, v as Link2, y as LayoutDashboard } from "../_libs/lucide-react.mjs";
import { t as Root } from "../_libs/radix-ui__react-label.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-BIcaNWAL.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var styles_default = "/assets/styles-7VngkVGe.css";
function reportLovableError(error, context = {}) {
	if (typeof window === "undefined") return;
	window.__lovableEvents?.captureException?.(error, {
		source: "react_error_boundary",
		route: window.location.pathname,
		...context
	}, {
		mechanism: "react_error_boundary",
		handled: false,
		severity: "error"
	});
	const message = error instanceof Response ? `Response ${error.status}${error.url ? ` at ${error.url}` : ""}` : error instanceof Error ? error.message : String(error);
	const stack = error instanceof Error ? error.stack : void 0;
	window.__lovableReportRuntimeError?.({
		message,
		...stack !== void 0 && { stack },
		filename: window.location.pathname
	});
}
function NotFoundComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-7xl font-bold text-foreground",
					children: "404"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 text-xl font-semibold text-foreground",
					children: "Page not found"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "The page you're looking for doesn't exist or has been moved."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/",
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Go home"
					})
				})
			]
		})
	});
}
function ErrorComponent({ error, reset }) {
	console.error(error);
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		reportLovableError(error, { boundary: "tanstack_root_error_component" });
	}, [error]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-semibold tracking-tight text-foreground",
					children: "This page didn't load"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Something went wrong on our end. You can try refreshing or head back home."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap justify-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							router.invalidate();
							reset();
						},
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Try again"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/",
						className: "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent",
						children: "Go home"
					})]
				})
			]
		})
	});
}
var Route$2 = createRootRouteWithContext()({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "AMEAS" },
			{
				name: "description",
				content: "Associação Movimento Esporte Adaptado e Superação"
			},
			{
				name: "author",
				content: "AMEAS"
			},
			{
				property: "og:title",
				content: "AMEAS"
			},
			{
				property: "og:description",
				content: "Associação Movimento Esporte Adaptado e Superação"
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			},
			{
				name: "twitter:site",
				content: "@Lovable"
			}
		],
		links: [{
			rel: "stylesheet",
			href: styles_default
		}, {
			rel: "icon",
			href: "/favicon.png",
			type: "image/png"
		}]
	}),
	shellComponent: RootShell,
	component: RootComponent,
	notFoundComponent: NotFoundComponent,
	errorComponent: ErrorComponent
});
function RootShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "pt-BR",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("head", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("script", { dangerouslySetInnerHTML: { __html: `(function(){try{if(localStorage.getItem('ameas-theme')==='light'){document.documentElement.classList.add('light-mode');}}catch(e){}})();` } })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})] })]
	});
}
function RootComponent() {
	const { queryClient } = Route$2.useRouteContext();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryClientProvider, {
		client: queryClient,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
	});
}
var $$splitComponentImporter = () => import("./routes-LkhxRCA3.mjs");
var Route$1 = createFileRoute("/")({
	head: () => ({ meta: [
		{ title: "AMEAS | Esporte Adaptado e Superação" },
		{
			name: "description",
			content: "Site institucional da AMEAS, associação que promove inclusão, acolhimento e superação por meio do esporte adaptado."
		},
		{
			property: "og:title",
			content: "AMEAS | Esporte Adaptado e Superação"
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
var Input = import_react.forwardRef(({ className, type, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		type,
		className: cn("flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-base shadow-sm transition-colors file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 md:text-sm", className),
		ref,
		...props
	});
});
Input.displayName = "Input";
var labelVariants = cva("text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70");
var Label = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Root, {
	ref,
	className: cn(labelVariants(), className),
	...props
}));
Label.displayName = Root.displayName;
var Textarea = import_react.forwardRef(({ className, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		className: cn("flex min-h-[60px] w-full rounded-md border border-input bg-transparent px-3 py-2 text-base shadow-sm placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 md:text-sm", className),
		ref,
		...props
	});
});
Textarea.displayName = "Textarea";
var Route = createFileRoute("/admin")({ component: AdminPage });
var ADMIN_LOGIN = "ameas";
var ADMIN_PASSWORD = "123456789";
var defaultPartnerLinks = [
	["rua-hum", "Rua Hum"],
	["escola-aquarela", "Escola Aquarela"],
	["ibicolor", "Ibicolor"],
	["vila-don-patto", "Vila Don Patto"],
	["unimed-sao-roque", "Unimed São Roque"],
	["emporio-qn", "Empório QN"],
	["tia-lina", "Tia Lina"],
	["fernando-araujo", "Fernando Araújo Artista Plástico"],
	["qualiser", "Qualiser Contabilidade"],
	["jornal-da-economia", "Jornal da Economia"]
].map(([slug, name], i) => ({
	slug,
	name,
	website_url: "",
	sort_order: i + 1,
	published: true
}));
function AdminPage() {
	const [loginInput, setLoginInput] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [isLoggedIn, setIsLoggedIn] = (0, import_react.useState)(false);
	const [content, setContent] = (0, import_react.useState)(defaultSiteContent);
	const [partnerLinks, setPartnerLinks] = (0, import_react.useState)(defaultPartnerLinks);
	const [uploads, setUploads] = (0, import_react.useState)([]);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [msg, setMsg] = (0, import_react.useState)(null);
	const [loginError, setLoginError] = (0, import_react.useState)("");
	const [tab, setTab] = (0, import_react.useState)("hero");
	const [isLight, setIsLight] = (0, import_react.useState)(() => {
		if (typeof window === "undefined") return false;
		return localStorage.getItem("ameas-theme") === "light";
	});
	function toggleTheme() {
		const next = !isLight;
		setIsLight(next);
		document.documentElement.classList.toggle("light-mode", next);
		localStorage.setItem("ameas-theme", next ? "light" : "dark");
	}
	(0, import_react.useEffect)(() => {
		if (!isLoggedIn || !supabase) return;
		supabase.from("ameas_partners").select("slug,name,website_url,sort_order,published").order("sort_order").then(({ data }) => {
			if (data?.length) setPartnerLinks(data);
		});
		supabase.from("ameas_site_content").select("key,value").then(({ data }) => {
			if (!data) return;
			const loaded = data.reduce((acc, row) => {
				if (row.key in acc) acc[row.key] = row.value;
				return acc;
			}, { ...defaultSiteContent });
			setContent(loaded);
		});
	}, [isLoggedIn]);
	const uploadLabel = (0, import_react.useMemo)(() => `${uploads.length} ${uploads.length === 1 ? "arquivo" : "arquivos"}`, [uploads.length]);
	function login() {
		if (loginInput === ADMIN_LOGIN && password === ADMIN_PASSWORD) {
			setIsLoggedIn(true);
			setLoginError("");
		} else setLoginError("Login ou senha incorretos.");
	}
	function onKey(e) {
		if (e.key === "Enter") login();
	}
	function notify(text, ok = true) {
		setMsg({
			text,
			ok
		});
		setTimeout(() => setMsg(null), 3500);
	}
	async function saveAll() {
		if (!supabase) return notify("Supabase não configurado.", false);
		setBusy(true);
		const rows = Object.entries(content).map(([key, value]) => ({
			key,
			value
		}));
		const { error } = await supabase.from("ameas_site_content").upsert(rows, { onConflict: "key" });
		setBusy(false);
		notify(error ? error.message : "Salvo com sucesso!", !error);
	}
	async function savePartners() {
		if (!supabase) return notify("Supabase não configurado.", false);
		setBusy(true);
		const { error } = await supabase.from("ameas_partners").upsert(partnerLinks, { onConflict: "slug" });
		setBusy(false);
		notify(error ? error.message : "Parceiros salvos!", !error);
	}
	async function uploadImages() {
		if (!supabase || !uploads.length) return notify("Selecione pelo menos uma imagem.", false);
		setBusy(true);
		const results = await Promise.all(uploads.map(async ({ file }) => {
			const path = `gallery/${crypto.randomUUID()}-${file.name.replace(/[^a-z0-9._-]/gi, "-")}`;
			const up = await supabase.storage.from("ameas-site-media").upload(path, file, { upsert: false });
			if (up.error) return up.error.message;
			const { data } = supabase.storage.from("ameas-site-media").getPublicUrl(path);
			return (await supabase.from("ameas_gallery_items").insert({
				title: file.name.replace(/\.[^.]+$/, ""),
				alt: "Imagem da AMEAS",
				image_url: data.publicUrl,
				sort_order: 0,
				published: true
			})).error?.message;
		}));
		setBusy(false);
		notify(results.filter(Boolean).join(" ") || `${uploads.length} imagem(ns) publicada(s)!`);
		setUploads([]);
	}
	function set(k, v) {
		setContent((c) => ({
			...c,
			[k]: v
		}));
	}
	if (!isLoggedIn) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "relative flex min-h-screen items-center justify-center overflow-hidden bg-background px-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute -top-40 left-1/2 h-96 w-96 -translate-x-1/2 rounded-full bg-[#1B4B8A]/20 blur-3xl" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute bottom-0 right-0 h-72 w-72 rounded-full bg-[#E8392A]/10 blur-3xl" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "glass-blue relative w-full max-w-sm overflow-hidden rounded-3xl border border-[#1B4B8A]/30 p-8 shadow-2xl backdrop-blur",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-6 text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl border border-[#1B4B8A]/40 bg-[#1B4B8A]/15 glow-blue",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LayoutDashboard, { className: "h-6 w-6 text-[#7eb5f5]" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "gradient-text text-2xl font-black",
							children: "Painel AMEAS"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-foreground/50",
							children: "Área restrita de gerenciamento"
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "login",
								className: "text-xs font-bold uppercase tracking-wide text-foreground/50",
								children: "Login"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "login",
								type: "text",
								value: loginInput,
								onChange: (e) => setLoginInput(e.target.value),
								onKeyDown: onKey,
								placeholder: "ameas",
								autoComplete: "username",
								className: "rounded-2xl border-border/40 bg-white/5 text-foreground placeholder:text-foreground/30"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "pw",
								className: "text-xs font-bold uppercase tracking-wide text-foreground/50",
								children: "Senha"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "pw",
								type: "password",
								value: password,
								onChange: (e) => setPassword(e.target.value),
								onKeyDown: onKey,
								autoComplete: "current-password",
								className: "rounded-2xl border-border/40 bg-white/5 text-foreground placeholder:text-foreground/30"
							})]
						}),
						loginError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "rounded-2xl border border-red-500/20 bg-red-500/10 px-4 py-2.5 text-sm text-red-400",
							children: loginError
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: login,
							className: "w-full rounded-2xl bg-[#1B4B8A] text-white shadow-lg shadow-[#1B4B8A]/30 hover:bg-[#1B4B8A]/90 hover:shadow-[#1B4B8A]/50",
							children: "Entrar no painel"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/",
							className: "block text-center text-sm text-foreground/40 hover:text-[#7eb5f5] transition-colors",
							children: "← Voltar para o site"
						})
					]
				})]
			})
		]
	});
	const tabs = [
		{
			id: "hero",
			label: "Hero / Sobre",
			icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, { className: "h-4 w-4" })
		},
		{
			id: "fundadora",
			label: "Fundadora",
			icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "h-4 w-4" })
		},
		{
			id: "organograma",
			label: "Organograma",
			icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LayoutDashboard, { className: "h-4 w-4" })
		},
		{
			id: "depoimentos",
			label: "Depoimentos",
			icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-4 w-4" })
		},
		{
			id: "pix",
			label: "PIX / Doação",
			icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QrCode, { className: "h-4 w-4" })
		},
		{
			id: "voluntario",
			label: "Voluntário",
			icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HandHeart, { className: "h-4 w-4" })
		},
		{
			id: "parceiros",
			label: "Parceiros",
			icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link2, { className: "h-4 w-4" })
		},
		{
			id: "galeria",
			label: "Galeria",
			icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, { className: "h-4 w-4" })
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "min-h-screen bg-background text-foreground",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "sticky top-0 z-40 border-b border-border/30 bg-background/85 backdrop-blur-2xl",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-7xl items-center justify-between px-4 py-3 sm:px-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex h-9 w-9 items-center justify-center rounded-xl border border-[#1B4B8A]/30 bg-[#1B4B8A]/10 glow-blue",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LayoutDashboard, { className: "h-4 w-4 text-[#7eb5f5]" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[10px] font-black uppercase tracking-widest text-[#7eb5f5]/70",
							children: "AMEAS CMS"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-black text-foreground",
							children: "Painel administrativo"
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/",
								className: "hidden rounded-xl border border-border/40 px-3 py-1.5 text-xs font-semibold text-foreground/50 hover:text-[#7eb5f5] sm:block transition-colors",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Globe, { className: "inline h-3.5 w-3.5 mr-1" }), "Ver site"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: toggleTheme,
								title: isLight ? "Modo Escuro" : "Modo Claro",
								className: "flex items-center gap-1.5 rounded-xl border border-border/40 px-3 py-1.5 text-xs font-semibold text-foreground/60 transition-all hover:border-[#1B4B8A]/40 hover:text-[#7eb5f5]",
								children: [isLight ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, { className: "h-3.5 w-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, { className: "h-3.5 w-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "hidden sm:inline",
									children: isLight ? "Escuro" : "Claro"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "ghost",
								size: "sm",
								onClick: () => setIsLoggedIn(false),
								className: "rounded-xl border border-border/30 text-xs text-foreground/50 hover:text-red-400 hover:border-red-500/30",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "mr-1.5 h-3.5 w-3.5" }), " Sair"]
							})
						]
					})]
				})
			}),
			msg && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: `fixed right-5 top-20 z-50 flex items-center gap-2 rounded-2xl border px-4 py-3 text-sm font-semibold shadow-xl backdrop-blur ${msg.ok ? "border-emerald-500/30 bg-emerald-500/15 text-emerald-400" : "border-red-500/30 bg-red-500/15 text-red-400"}`,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-4 w-4 shrink-0" }),
					" ",
					msg.text
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-7xl px-4 py-8 sm:px-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mb-6 grid gap-3 sm:grid-cols-4",
						children: [
							{
								label: "Status",
								value: "Publicado",
								color: "text-emerald-400"
							},
							{
								label: "Admin",
								value: "ameas",
								color: "text-[#7eb5f5]"
							},
							{
								label: "Parceiros",
								value: `${partnerLinks.length}`,
								color: "text-[#38bdf8]"
							},
							{
								label: "Upload",
								value: uploadLabel,
								color: "text-[#f59e0b]"
							}
						].map(({ label, value, color }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "glass rounded-2xl border border-border/30 p-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-foreground/40",
								children: label
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: `mt-1 text-base font-black ${color}`,
								children: value
							})]
						}, label))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mb-6 overflow-x-auto",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex min-w-max gap-1 rounded-2xl border border-border/30 bg-secondary/30 p-1",
							children: tabs.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: () => setTab(t.id),
								className: `flex items-center gap-1.5 rounded-xl px-3 py-2 text-xs font-bold whitespace-nowrap transition-all ${tab === t.id ? "bg-[#1B4B8A]/25 text-[#7eb5f5] border border-[#1B4B8A]/30 glow-blue" : "text-foreground/50 hover:text-foreground"}`,
								children: [
									t.icon,
									" ",
									t.label
								]
							}, t.id))
						})
					}),
					tab === "hero" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminCard, {
						title: "Hero e Sobre",
						desc: "Textos principais da página inicial.",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-5 sm:grid-cols-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
									label: "Título do hero",
									value: content.hero_title,
									onChange: (v) => set("hero_title", v)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
									label: "WhatsApp",
									value: content.contact_whatsapp,
									onChange: (v) => set("contact_whatsapp", v)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "sm:col-span-2",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
										label: "Subtítulo do hero",
										value: content.hero_subtitle,
										onChange: (v) => set("hero_subtitle", v),
										multi: true
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "sm:col-span-2",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
										label: "Texto sobre a AMEAS",
										value: content.about_text,
										onChange: (v) => set("about_text", v),
										multi: true
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
									label: "Instagram URL",
									value: content.instagram_url,
									onChange: (v) => set("instagram_url", v)
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SaveBtn, {
							onClick: saveAll,
							busy
						})]
					}),
					tab === "fundadora" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminCard, {
						title: "Seção Fundadora",
						desc: "Nome e textos biográficos da fundadora.",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
									label: "Nome da fundadora",
									value: content.founder_name,
									onChange: (v) => set("founder_name", v)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
									label: "Biografia — parágrafo 1",
									value: content.founder_bio1,
									onChange: (v) => set("founder_bio1", v),
									multi: true
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
									label: "Biografia — parágrafo 2",
									value: content.founder_bio2,
									onChange: (v) => set("founder_bio2", v),
									multi: true
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SaveBtn, {
							onClick: saveAll,
							busy
						})]
					}),
					tab === "organograma" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminCard, {
						title: "Organograma",
						desc: "Nomes dos cargos exibidos no organograma hierárquico.",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-5 sm:grid-cols-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
									label: "Presidente",
									value: content.org_president_name,
									onChange: (v) => set("org_president_name", v)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
									label: "Vice-Presidente",
									value: content.org_vp_name,
									onChange: (v) => set("org_vp_name", v)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "sm:col-span-2 border-t border-border/20 pt-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mb-3 text-xs font-black uppercase tracking-widest text-[#7eb5f5]/70",
										children: "Secretaria"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid gap-4 sm:grid-cols-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
											label: "Primeiro Secretário",
											value: content.org_sec1_name,
											onChange: (v) => set("org_sec1_name", v)
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
											label: "Segundo Secretário",
											value: content.org_sec2_name,
											onChange: (v) => set("org_sec2_name", v)
										})]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "sm:col-span-2 border-t border-border/20 pt-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mb-3 text-xs font-black uppercase tracking-widest text-[#38bdf8]/70",
										children: "Tesouraria"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid gap-4 sm:grid-cols-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
											label: "Primeiro Tesoureiro",
											value: content.org_treas1_name,
											onChange: (v) => set("org_treas1_name", v)
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
											label: "Segundo Tesoureiro",
											value: content.org_treas2_name,
											onChange: (v) => set("org_treas2_name", v)
										})]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "sm:col-span-2 border-t border-border/20 pt-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mb-3 text-xs font-black uppercase tracking-widest text-[#E8392A]/70",
										children: "Fiscalização"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid gap-4 sm:grid-cols-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
											label: "Primeiro Fiscal",
											value: content.org_audit1_name,
											onChange: (v) => set("org_audit1_name", v)
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
											label: "Segundo Fiscal",
											value: content.org_audit2_name,
											onChange: (v) => set("org_audit2_name", v)
										})]
									})]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SaveBtn, {
							onClick: saveAll,
							busy
						})]
					}),
					tab === "depoimentos" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminCard, {
						title: "Depoimentos",
						desc: "Os três depoimentos exibidos na seção de vozes.",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "space-y-6",
							children: [
								1,
								2,
								3
							].map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-2xl border border-border/20 bg-secondary/20 p-5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mb-3 text-xs font-black uppercase tracking-widest text-foreground/40",
									children: ["Depoimento ", n]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid gap-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
										label: "Texto da citação",
										value: content[`test${n}_quote`],
										onChange: (v) => set(`test${n}_quote`, v),
										multi: true
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
										label: "Autor",
										value: content[`test${n}_author`],
										onChange: (v) => set(`test${n}_author`, v)
									})]
								})]
							}, n))
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SaveBtn, {
							onClick: saveAll,
							busy
						})]
					}),
					tab === "pix" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminCard, {
						title: "PIX e Dados Bancários",
						desc: "Informações de doação exibidas no site e no modal de PIX.",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-5 sm:grid-cols-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "sm:col-span-2",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
											label: "Chave PIX (CNPJ)",
											value: content.pix_key,
											onChange: (v) => set("pix_key", v)
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
										label: "Banco",
										value: content.pix_bank,
										onChange: (v) => set("pix_bank", v)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
										label: "Agência",
										value: content.pix_agency,
										onChange: (v) => set("pix_agency", v)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
										label: "Conta Corrente",
										value: content.pix_account,
										onChange: (v) => set("pix_account", v)
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-5 rounded-2xl border border-[#1B4B8A]/20 bg-[#1B4B8A]/5 p-4 text-sm text-foreground/60",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-bold text-[#7eb5f5] mb-1",
										children: "Prévia no site:"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["PIX CNPJ ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
										className: "text-foreground",
										children: content.pix_key
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
										content.pix_bank,
										" · Ag. ",
										content.pix_agency,
										" · CC ",
										content.pix_account
									] })
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SaveBtn, {
								onClick: saveAll,
								busy
							})
						]
					}),
					tab === "voluntario" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminCard, {
						title: "Seção Voluntário",
						desc: "Título e descrição do card de voluntariado na seção Como Ajudar.",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
								label: "Título",
								value: content.volunteer_title,
								onChange: (v) => set("volunteer_title", v)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
								label: "Descrição",
								value: content.volunteer_desc,
								onChange: (v) => set("volunteer_desc", v),
								multi: true
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SaveBtn, {
							onClick: saveAll,
							busy
						})]
					}),
					tab === "parceiros" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminCard, {
						title: "Links dos Parceiros",
						desc: "O logo de cada parceiro ficará clicável no site. Ative/desative a visibilidade.",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "space-y-3",
							children: partnerLinks.map((p, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid items-center gap-3 rounded-2xl border border-border/20 bg-secondary/20 p-4 sm:grid-cols-[1fr_2fr_auto]",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs font-black text-foreground/80",
										children: p.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[10px] text-foreground/40 uppercase tracking-wide",
										children: p.slug
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "url",
										placeholder: "https://...",
										value: p.website_url,
										onChange: (e) => setPartnerLinks(partnerLinks.map((x, j) => j === i ? {
											...x,
											website_url: e.target.value
										} : x)),
										className: "rounded-xl border-border/30 bg-white/5 text-sm text-foreground placeholder:text-foreground/30"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onClick: () => setPartnerLinks(partnerLinks.map((x, j) => j === i ? {
											...x,
											published: !x.published
										} : x)),
										className: `rounded-xl border px-3 py-1.5 text-xs font-bold transition-all ${p.published ? "border-emerald-500/30 bg-emerald-500/15 text-emerald-400" : "border-border/30 text-foreground/40"}`,
										children: p.published ? "Visível" : "Oculto"
									})
								]
							}, p.slug))
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							onClick: savePartners,
							disabled: busy,
							className: "mt-6 rounded-2xl bg-[#1B4B8A] text-white hover:bg-[#1B4B8A]/90",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, { className: "mr-2 h-4 w-4" }),
								" ",
								busy ? "Salvando…" : "Salvar parceiros"
							]
						})]
					}),
					tab === "galeria" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminCard, {
						title: "Galeria de Fotos",
						desc: "Selecione várias imagens. Elas vão para o storage seguro do Supabase.",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex min-h-40 cursor-pointer flex-col items-center justify-center rounded-2xl border-2 border-dashed border-[#1B4B8A]/30 bg-[#1B4B8A]/5 p-8 text-center transition hover:border-[#1B4B8A]/60 hover:bg-[#1B4B8A]/10",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "mb-3 h-8 w-8 text-[#7eb5f5]" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-black text-foreground",
									children: "Clique para selecionar fotos"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-1 text-sm text-foreground/50",
									children: "PNG, JPG ou WEBP · múltipla seleção"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "file",
									accept: "image/png,image/jpeg,image/webp",
									multiple: true,
									className: "sr-only",
									onChange: (e) => setUploads(Array.from(e.target.files ?? []).map((f) => ({
										file: f,
										url: URL.createObjectURL(f)
									})))
								})
							]
						}), uploads.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-5 grid grid-cols-3 gap-3 sm:grid-cols-5 lg:grid-cols-8",
							children: uploads.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "group relative aspect-square overflow-hidden rounded-xl",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: item.url,
									alt: item.file.name,
									className: "h-full w-full object-cover"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: () => setUploads(uploads.filter((u) => u.url !== item.url)),
									className: "absolute right-1 top-1 flex h-5 w-5 items-center justify-center rounded-full bg-red-500/80 text-white opacity-0 transition group-hover:opacity-100",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-3 w-3" })
								})]
							}, item.url))
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							onClick: uploadImages,
							disabled: busy,
							className: "mt-5 rounded-2xl bg-[#1B4B8A] text-white hover:bg-[#1B4B8A]/90",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "mr-2 h-4 w-4" }),
								" ",
								busy ? "Enviando…" : `Publicar ${uploads.length} imagem(ns)`
							]
						})] })]
					})
				]
			})
		]
	});
}
function AdminCard({ title, desc, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "glass rounded-3xl border border-border/30 p-6 sm:p-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-lg font-black text-foreground",
				children: title
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-foreground/50",
				children: desc
			})]
		}), children]
	});
}
function SaveBtn({ onClick, busy }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
		onClick,
		disabled: busy,
		className: "mt-6 rounded-2xl bg-[#1B4B8A] text-white hover:bg-[#1B4B8A]/90",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, { className: "mr-2 h-4 w-4" }),
			" ",
			busy ? "Salvando…" : "Salvar alterações"
		]
	});
}
function F({ label, value, onChange, multi = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-1.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
			className: "text-xs font-bold uppercase tracking-wide text-foreground/50",
			children: label
		}), multi ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
			value,
			onChange: (e) => onChange(e.target.value),
			rows: 3,
			className: "rounded-xl border-border/30 bg-white/5 text-foreground resize-none"
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
			value,
			onChange: (e) => onChange(e.target.value),
			className: "rounded-xl border-border/30 bg-white/5 text-foreground"
		})]
	});
}
var rootRouteChildren = {
	IndexRoute: Route$1.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$2
	}),
	AdminRoute: Route.update({
		id: "/admin",
		path: "/admin",
		getParentRoute: () => Route$2
	})
};
var routeTree = Route$2._addFileChildren(rootRouteChildren)._addFileTypes();
function getRouter() {
	const queryClient = new QueryClient();
	return createRouter({
		routeTree,
		context: { queryClient },
		defaultPreload: "intent",
		scrollRestoration: true
	});
}
//#endregion
export { getRouter };
